/**
 * Library search: finding the source, and saying how it was found.
 *
 * Search here has one unusual requirement. It has to report *which retrieval
 * path produced a result*, because the two paths make different promises. A
 * lexical hit means those characters are in that source at that moment. A
 * semantic hit means something in that source was near the query in an
 * embedding space, which is a much weaker claim and occasionally a wrong one.
 *
 * A product that merged them into one ranked list with one relevance number
 * would be a product where "it found nothing" and "the embedding model was not
 * installed" look identical, and where a paraphrase match and an exact quote
 * look equally certain. So {@link searchPlan} states the path before anything
 * runs, and every hit carries the path that produced it.
 *
 * Facets are computed from the results rather than from a fixed taxonomy. A
 * facet that offers "Arabic (0)" on a library with no Arabic in it is a filter
 * that teaches people the filter is broken.
 *
 * @module @watchskill/dsh-library/search
 */
import type { TemporalRange } from '@watchskill/dsh-contracts';
import type { Source, SourceKind, IndexState } from './sources.js';
/** How a result was retrieved. */
export type RetrievalPath = 'lexical' | 'semantic' | 'both';
/** What the engine can actually do here. */
export interface SearchCapabilities {
    /** Substring and token matching over extracted text. */
    readonly lexical: boolean;
    /** Embedding retrieval. Requires a bound embeddings role. */
    readonly semantic: boolean;
}
/** What search will do, decided before it runs. */
export interface SearchPlan {
    readonly path: RetrievalPath | 'none';
    /** One sentence for the results header. Always populated. */
    readonly explanation: string;
    /** What is missing, and what to do about it. Empty when nothing is. */
    readonly degradedBecause: string;
    readonly fix: string;
}
/**
 * Decide the retrieval path.
 *
 * Semantic-only is a real state and is reported as one rather than silently
 * treated as "search works". A library where exact-phrase search is
 * unavailable behaves very differently from one where it is not, and a user
 * searching for an error code needs to know which they are in.
 */
export declare function searchPlan(capabilities: SearchCapabilities): SearchPlan;
/** One hit inside one source. */
export interface SearchHit {
    readonly sourceId: string;
    readonly sourceRevisionId: string;
    /** Where in the source, when the modality has a clock. */
    readonly range: TemporalRange | null;
    /** The matched text, verbatim and in its original script. */
    readonly text: string;
    /** Which path produced this hit. */
    readonly path: RetrievalPath;
    /**
     * Score, in the producing path's own units.
     *
     * Deliberately not normalized across paths. A lexical rank and a cosine
     * similarity are not comparable, and putting them on one 0–1 scale would
     * manufacture a comparison that does not exist.
     */
    readonly score: number;
    /** Evidence this hit resolves to, when the engine minted any. */
    readonly evidenceIds: readonly string[];
}
/** A result: one source, and the hits inside it. */
export interface SearchResult {
    readonly sourceId: string;
    readonly title: string;
    readonly kind: SourceKind;
    readonly hits: readonly SearchHit[];
    /** Whether the hits are against the source's current revision. */
    readonly current: boolean;
}
/** One facet value and how many results carry it. */
export interface FacetValue {
    readonly value: string;
    readonly count: number;
}
/** The facets computed from a result set. */
export interface Facets {
    readonly kind: readonly FacetValue[];
    readonly indexState: readonly FacetValue[];
    readonly collection: readonly FacetValue[];
    readonly script: readonly FacetValue[];
    readonly path: readonly FacetValue[];
}
/** What a search was narrowed to. */
export interface SearchFilters {
    readonly kinds?: readonly SourceKind[];
    readonly collections?: readonly string[];
    readonly indexStates?: readonly IndexState[];
    readonly scripts?: readonly string[];
    /** Only hits from the current revision of each source. */
    readonly currentOnly?: boolean;
}
/**
 * Compute facets over a result set.
 *
 * Only values that actually occur. A facet list generated from the schema
 * rather than from the results offers filters that return nothing, and a
 * filter that returns nothing is indistinguishable from a broken one.
 */
export declare function facetsFor(results: readonly SearchResult[], sources: readonly Source[]): Facets;
/** Apply filters to a result set. Pure; the engine does the retrieval. */
export declare function applyFilters(results: readonly SearchResult[], sources: readonly Source[], filters: SearchFilters): readonly SearchResult[];
/**
 * Order results for display.
 *
 * Within a source, hits are ordered by path and then by time — not by score
 * across paths, because the scores are not comparable. Across sources, the
 * source with the strongest lexical evidence leads, because an exact match is
 * the strongest claim search can make.
 */
export declare function rankResults(results: readonly SearchResult[]): readonly SearchResult[];
/**
 * One line above the results, stating what was searched and how.
 *
 * Always says the path. "12 results" alone invites the reading that the library
 * was searched thoroughly, which may not be true.
 */
export declare function describeSearch(plan: SearchPlan, results: readonly SearchResult[]): string;
//# sourceMappingURL=search.d.ts.map