/**
 * The Library surface, registered into DSH's slots.
 *
 * @module @watchskill/dsh-library/client
 */
import type { Context } from '@deepseek-ai/cordis';
export * from './components.js';
export * from '../sources.js';
export * from '../search.js';
/** Services this half needs before it can register anything. */
export declare const inject: string[];
/** Register the Library mode body. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map