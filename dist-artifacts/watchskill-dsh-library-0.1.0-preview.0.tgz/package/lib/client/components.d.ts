/**
 * The Library surface.
 *
 * Visually and structurally separate from Memory, and that separation is
 * enforced rather than encouraged: this module imports nothing from the memory
 * packages, so a memory record cannot be rendered here even by mistake. The
 * two surfaces answer different questions — what has been seen, and what is
 * believed — and a person needs to be able to tell at a glance which one they
 * are looking at.
 *
 * Every result says how it was found and whether it is still current. A search
 * result that showed neither would be a list of claims about a library whose
 * state the reader cannot check.
 *
 * @module @watchskill/dsh-library/components
 */
import type { ReactNode } from 'react';
import type { Freshness } from '@watchskill/dsh-contracts';
import { type Source, type SourceRevision } from '../sources.js';
import { type Facets, type SearchHit, type SearchPlan, type SearchResult } from '../search.js';
/** Props for {@link FreshnessBadge}. */
export interface FreshnessBadgeProps {
    readonly freshness: Freshness;
}
/** Freshness as glyph, word and tone. */
export declare function FreshnessBadge({ freshness }: FreshnessBadgeProps): ReactNode;
/** Props for {@link RevisionHistory}. */
export interface RevisionHistoryProps {
    readonly source: Source;
    readonly onOpen: (revision: SourceRevision) => void;
}
/**
 * A source's revisions, newest last.
 *
 * Every revision is listed, including superseded ones, and every one is
 * openable. A history that showed only the current revision would make old
 * evidence unreachable through the interface even though it remains
 * addressable underneath, which is the same failure with extra steps.
 */
export declare function RevisionHistory({ source, onOpen }: RevisionHistoryProps): ReactNode;
/** Props for {@link SearchHitRow}. */
export interface SearchHitRowProps {
    readonly hit: SearchHit;
    readonly freshness: Freshness;
    readonly onOpen: (hit: SearchHit) => void;
}
/**
 * One hit.
 *
 * The retrieval path is on the row, not in a legend. A person reading a
 * semantic hit needs to know it is a semantic hit at the moment they read it,
 * because that is what decides whether they should check it.
 */
export declare function SearchHitRow({ hit, freshness, onOpen }: SearchHitRowProps): ReactNode;
/** Props for {@link FacetPanel}. */
export interface FacetPanelProps {
    readonly facets: Facets;
    readonly onFilter: (facet: string, value: string) => void;
}
/** The facet rail. Only values that actually occur are offered. */
export declare function FacetPanel({ facets, onFilter }: FacetPanelProps): ReactNode;
/** Props for {@link LibrarySurface}. */
export interface LibrarySurfaceProps {
    readonly plan: SearchPlan;
    readonly results: readonly SearchResult[];
    readonly facets: Facets;
    readonly sources: readonly Source[];
    readonly freshnessOf: (hit: SearchHit) => Freshness;
    readonly onOpenHit: (hit: SearchHit) => void;
    readonly onOpenRevision: (revision: SourceRevision) => void;
    readonly onFilter: (facet: string, value: string) => void;
}
/** The Library mode body. */
export declare function LibrarySurface(props: LibrarySurfaceProps): ReactNode;
//# sourceMappingURL=components.d.ts.map