/**
 * The Watch brand, occupying DSH's generic brand slots.
 *
 * `ui-brand-official` is the one entry in the parity register marked
 * `intentionally_replaced`, and this is the replacement. The slots it fills are
 * upstream's own, declared generic precisely so a distribution can supply its
 * own identity; nothing is patched.
 *
 * Attribution and the independence disclosure travel with the mark rather than
 * being left to whoever assembles a footer. They are legal statements, and a
 * legal statement that depends on being remembered will eventually not be.
 *
 * @module @watchskill/dsh-client-brand/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { PRODUCT_SHORT_NAME } from '../identity.js';
import './theme.css';
export * from '../identity.js';
/** Services this half needs before it can register anything. */
export declare const inject: string[];
/** Occupy the generic brand slots with the Watch identity. */
export declare function apply(ctx: Context): void;
export { PRODUCT_SHORT_NAME };
//# sourceMappingURL=index.d.ts.map