/**
 * The Watch product identity, and the one colour rule that matters.
 *
 * Kept as data rather than as markup so the same strings reach the sidebar,
 * the conversation hero, the About panel, the window title and the release
 * notes without four copies drifting apart. Attribution in particular has to
 * be identical everywhere it appears, because it is a legal statement rather
 * than a design element.
 *
 * @module @watchskill/dsh-client-brand/identity
 */
/** What the product is called. Never "DeepSeek" anything. */
export declare const PRODUCT_NAME = "Watch Workspace";
/** The short form, for a tab title or a cramped header. */
export declare const PRODUCT_SHORT_NAME = "Watch";
/**
 * Attribution to the upstream project.
 *
 * Required, and required to be visible. Watch is built on DeepSeek Harness and
 * says so; the alternative — quietly shipping someone else's foundation — is
 * both wrong and against the MIT notice this distribution inherits.
 */
export declare const ATTRIBUTION = "Built on DeepSeek Harness \u00B7 Extended by Watch Skill";
/**
 * The independence disclosure.
 *
 * Equally required, and for the opposite reason: attribution without it could
 * read as endorsement, and no such endorsement exists.
 */
export declare const INDEPENDENCE = "Watch Skill is an independent project and is not affiliated with or endorsed by DeepSeek.";
/** One line for a tooltip or an empty state. */
export declare const TAGLINE = "An agent that sees, remembers, and can prove what actually happened.";
/**
 * The status vocabulary, and the tone each one is allowed.
 *
 * This table is the visual half of ADR-002. `success` appears exactly once, on
 * `VERIFIED`, and nothing else in the product may reach it — not a high
 * confidence, not a completed agent turn, not five checks out of six.
 *
 * `caution` covers the honest non-answers. They are deliberately not `error`:
 * styling an unproven result as a failure teaches people to dismiss it, which
 * is how "not proven" quietly becomes "proven".
 */
export type BrandTone = 'success' | 'error' | 'caution' | 'info' | 'active' | 'neutral';
/** Every status the product renders, and the tone it is permitted. */
export declare const STATUS_TONE: {
    readonly VERIFIED: "success";
    readonly FAILED: "error";
    readonly UNVERIFIED: "caution";
    readonly INCONCLUSIVE: "caution";
    readonly STALE: "caution";
    readonly BLOCKED: "caution";
    readonly queued: "neutral";
    readonly running: "active";
    readonly completed: "info";
    readonly failed: "error";
    readonly cancelled: "neutral";
    readonly current: "neutral";
    readonly gap: "caution";
    readonly expired: "caution";
    readonly unavailable: "caution";
};
/** A status this product knows how to render. */
export type BrandStatus = keyof typeof STATUS_TONE;
/**
 * The tone one status is allowed.
 *
 * Anything unrecognized is `neutral`, never `success`. A new status added
 * elsewhere and not registered here renders as unremarkable rather than
 * accidentally as a win.
 */
export declare function toneFor(status: string): BrandTone;
/** Whether a status may be rendered with the success affordance. */
export declare function isSuccessTone(status: string): boolean;
/**
 * The semantic token a tone maps to.
 *
 * Feature packages ask for a tone and get a CSS variable. They never write a
 * hex value, which is what stops the palette from being re-invented slightly
 * differently in every panel — and what makes a theme change one edit.
 */
export declare function tokenFor(tone: BrandTone): string;
//# sourceMappingURL=identity.d.ts.map