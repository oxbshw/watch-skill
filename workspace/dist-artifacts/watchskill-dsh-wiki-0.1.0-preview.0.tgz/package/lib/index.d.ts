/**
 * Deterministic workspace wiki projections.
 *
 * @module @watchskill/dsh-wiki
 */
export * from './projection.js';
//# sourceMappingURL=index.d.ts.map