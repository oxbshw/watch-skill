/**
 * The workspace wiki: readable pages that are never the record.
 *
 * A wiki is the most natural thing to build over a memory ledger and the
 * easiest one to build wrong. The wrong version is a folder of Markdown that
 * people edit, that the agent reads, and that gradually becomes the actual
 * state of the system — at which point the ledger is a log of things that used
 * to be true, and a file nobody audited is deciding how an agent behaves.
 *
 * So the direction of authority is fixed and one-way:
 *
 *   MemoryEvent ledger  →  records  →  wiki pages
 *
 * Pages are generated. They are deleted and regenerated on every rebuild, they
 * carry no state of their own, and nothing reads them back as fact. Every
 * generated statement carries the memory id it came from, both so a reader can
 * follow it and so a statement *without* one is visibly not from the ledger.
 *
 * Hand editing is supported, and it does not reverse the arrow. An edited file
 * is diffed against what the generator would have produced; the difference is
 * validated; what survives becomes a `user.edited` event in the ledger; and
 * then the page is regenerated from the ledger, which is what puts the edit on
 * screen. If validation refuses the edit, the regeneration simply removes it —
 * the file was never the record, so nothing was lost that was ever held.
 *
 * The refusals matter more than the acceptances. Imported Markdown is
 * `imported` origin, the weakest there is. It cannot mint `explicit_user`, it
 * cannot carry a high-impact permission, and it cannot assert something about a
 * protected subject. A document that says "the user has approved all uploads"
 * is a claim made by a document.
 *
 * @module @watchskill/dsh-wiki/projection
 */
import type { MemoryEvent, MemoryRecord } from '@watchskill/dsh-memory';
/** A generated page. */
export interface WikiPage {
    /** Path relative to the wiki root, always forward-slashed. */
    readonly path: string;
    readonly title: string;
    readonly content: string;
    /** Memory ids every statement on this page came from. */
    readonly provenance: readonly string[];
    /**
     * Always true.
     *
     * Present as a field rather than as a comment so a consumer cannot treat a
     * page as authored. There is no code path that produces a page with this
     * false, and that is the point.
     */
    readonly generated: true;
}
/** The whole wiki, as a value. */
export interface WikiProjection {
    readonly pages: readonly WikiPage[];
    /** Rebuild digest. The same ledger renders the same wiki. */
    readonly digest: string;
}
/** The directories the wiki is organized into. */
export declare const WIKI_SECTIONS: readonly ["projects", "people", "concepts", "decisions", "lessons", "failures"];
/** One wiki section. */
export type WikiSection = typeof WIKI_SECTIONS[number];
/**
 * A stable, filesystem-safe slug.
 *
 * Deliberately does not transliterate. A page about an Arabic concept keeps
 * its identity in the title, and the slug falls back to the memory id rather
 * than to a mangled romanization that would collide with every other one.
 */
export declare function slugFor(record: MemoryRecord): string;
/**
 * Build the whole wiki from the ledger.
 *
 * A pure fold. Rebuilding from an empty index directory, from a cold start, or
 * after a restart produces the identical bytes, which is what makes "the wiki
 * is a projection" a testable claim rather than a design intention.
 *
 * Deleted records are absent because the fold that produced `records` already
 * excluded them. There is no separate wiki deletion path, and therefore no
 * separate wiki deletion path to forget to run.
 */
export declare function buildWiki(records: readonly MemoryRecord[], events?: readonly MemoryEvent[]): WikiProjection;
/** Look one page up by path. */
export declare function pageAt(projection: WikiProjection, path: string): WikiPage | null;
/** One line a person added or removed. */
export interface EditedLine {
    readonly text: string;
    /** The memory id the line claimed, when it carried a marker. */
    readonly memoryId: string | null;
}
/** What a hand edit proposes. */
export interface EditProposal {
    readonly path: string;
    readonly added: readonly EditedLine[];
    readonly removed: readonly EditedLine[];
}
/**
 * Diff a hand-edited page against what the generator produced.
 *
 * Line-level and deliberately crude. A structural Markdown diff would be more
 * precise and would also be a place for a clever edit to hide; comparing the
 * statement lines catches everything that could carry a claim.
 */
export declare function diffUserEdit(generated: WikiPage, edited: string): EditProposal;
/** Why one edited line was refused. */
export interface EditRefusal {
    readonly line: string;
    readonly reason: string;
    readonly fix: string;
}
/** What survived validation, and what did not. */
export interface ValidatedEdit {
    readonly path: string;
    /** Lines that may become `user.edited` events. */
    readonly accepted: readonly EditedLine[];
    readonly refused: readonly EditRefusal[];
    /** Memory ids the edit asks to remove. */
    readonly removals: readonly string[];
}
/**
 * Validate a hand edit.
 *
 * Four refusals, each closing a way a file could write itself into authority:
 *
 * - **A forged marker.** A line carrying `mem:` for an id the page does not
 *   own is trying to attribute a new claim to an existing record.
 * - **High impact.** A permission, a standing grant, a weakened safeguard.
 *   Imported text is the weakest origin there is; it does not get to authorize
 *   anything, at any confidence.
 * - **A protected subject.** Health, beliefs, and the rest are things a person
 *   states about themselves. A file stating them is a file making a claim.
 * - **An empty claim.** A marker with no statement is a way to create a record
 *   with no content and then fill it later.
 *
 * Everything accepted becomes `imported` origin and `proposed` status. Nothing
 * a file says can make it `explicit_user`, because that origin means a person
 * did something, and reading a file is not a person doing something.
 */
export declare function validateUserEdit(proposal: EditProposal, generated: WikiPage): ValidatedEdit;
/** A candidate the ledger may admit, produced from an accepted edit line. */
export interface ImportedCandidate {
    readonly kind: MemoryRecord['kind'];
    readonly content: string;
    readonly origin: 'imported';
    readonly subjectScope: MemoryRecord['subjectScope'];
    readonly scopeId: string;
    readonly confidence: number;
    readonly sourceRefs: readonly string[];
}
/**
 * Turn accepted edit lines into ledger candidates.
 *
 * `imported` origin and a low confidence, always, whatever the file said. The
 * scope comes from the caller — the wiki knows which workspace it belongs to
 * and a file does not get to choose.
 */
export declare function toCandidates(edit: ValidatedEdit, scope: {
    readonly subjectScope: MemoryRecord['subjectScope'];
    readonly scopeId: string;
}): readonly ImportedCandidate[];
/**
 * One line describing what a hand edit will actually do.
 *
 * Shown before the edit is applied. "3 accepted, 1 refused" is what stops a
 * person believing their file is now the state of the system.
 */
export declare function describeEdit(edit: ValidatedEdit): string;
//# sourceMappingURL=projection.d.ts.map