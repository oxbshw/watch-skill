/**
 * The OCR engine family, and what it is honest to claim about each one.
 *
 * The governing decision (spec §33): DeepSeek-OCR is integrated as an
 * **optional, measured engine**, not as a dependency and not as the only
 * source of text. OCR2 is the high-quality document candidate where the
 * hardware suits it; the lightweight local route stays the default because it
 * is what works on a laptop with no GPU, which is most machines.
 *
 * Two rules are structural here rather than advisory.
 *
 * **Isolation.** DeepSeek-OCR's published inference path uses
 * `trust_remote_code=True`. That code does not run inside the DSH Host or the
 * Watch Core main process — it runs in a worker with a pinned revision, so a
 * crash, an OOM or a surprise in a model repository takes down a worker
 * instead of the workspace.
 *
 * **Qualification is per workload, never a single score.** An engine that
 * scores well on clean documents can be worse than a lighter one on subtitles,
 * dark-mode UI, or mixed scripts. One global number would hide exactly the
 * cases a user cares about, so the matrix is per engine × workload × script.
 *
 * @module @watchskill/dsh-technology/ocr
 */
import type { TechnologyDescriptor } from './descriptor.js';
/** The workloads OCR is judged against separately. */
export type OcrWorkload = 'ui_text' | 'browser_form' | 'subtitles' | 'video_overlay' | 'document' | 'table' | 'reading_order' | 'low_resolution' | 'dark_mode' | 'mixed_script';
/** Every workload, for enumerating a qualification matrix. */
export declare const OCR_WORKLOADS: readonly OcrWorkload[];
/**
 * The scripts the matrix is structured around.
 *
 * Structural support, stated separately from measured results. A script
 * appearing here means the contract handles it, not that any engine has been
 * qualified on it.
 */
export type ScriptTag = 'Latin' | 'Arabic' | 'Han_Simplified' | 'Han_Traditional' | 'Japanese' | 'Korean' | 'Cyrillic' | 'Devanagari' | 'Thai' | 'Greek' | 'Hebrew' | 'Mixed';
/** Every script the matrix is structured around. */
export declare const SCRIPTS: readonly ScriptTag[];
/**
 * What can be said about an engine on one workload.
 *
 * `NOT_TESTED` and `NOT_YET_QUALIFIED` are different answers, and keeping them
 * apart is the whole point. The first means nobody ran it; the second means
 * somebody did and it was not good enough. Collapsing them would let an
 * untested engine look evaluated.
 */
export type QualificationState = 'QUALIFIED' | 'QUALIFIED_WITH_LIMITATIONS' | 'NOT_YET_QUALIFIED' | 'NOT_TESTED';
/** One cell of the matrix. */
export interface QualificationEntry {
    readonly engineId: string;
    readonly workload: OcrWorkload;
    readonly script: ScriptTag;
    readonly state: QualificationState;
    /** Measured values. Empty when nothing was measured — never estimated. */
    readonly metrics: Readonly<Record<string, number>>;
    /** Why it is limited, when it is. */
    readonly limitations: readonly string[];
    /** ISO-8601, or null when never run. */
    readonly measuredAt: string | null;
    /** The machine it was measured on, so a number is attributable. */
    readonly measuredOn: string | null;
}
/** An untested cell: structurally present, honestly empty. */
export declare function notTested(engineId: string, workload: OcrWorkload, script: ScriptTag): QualificationEntry;
/**
 * Whether an engine may be selected as a default for a workload.
 *
 * Only a qualified engine. An untested one may be *chosen* by a user who wants
 * it, but it never becomes what happens when nobody chose — which is the
 * mechanism by which "we integrated OCR2" would otherwise turn into "OCR2 runs
 * on everything, including the cases it is bad at".
 */
export declare function canDefault(entry: QualificationEntry): boolean;
/** The canonical OCR result, whatever engine produced it. */
export interface OcrResult {
    readonly ocrResultId: string;
    readonly sourceRevisionId: string;
    /** Digest of the exact image this was read from. */
    readonly artifactDigest: string;
    readonly temporalRangeMs: {
        readonly startMs: number;
        readonly endMs: number;
    } | null;
    readonly frameIndex: number | null;
    readonly engineId: string;
    readonly model: string;
    readonly revision: string;
    /** Which prompt profile was used, for an engine that has them. */
    readonly promptProfile: string | null;
    readonly preprocessing: Readonly<Record<string, unknown>>;
    readonly text: string;
    readonly blocks: readonly OcrBlock[];
    readonly readingOrder: readonly number[] | null;
    readonly markdown: string | null;
    readonly languageTags: readonly string[];
    readonly scripts: readonly ScriptTag[];
    readonly latencyMs: number;
    readonly resourceUsage: Readonly<Record<string, number>>;
    readonly qualityWarnings: readonly string[];
    /**
     * Null unless the engine produces a *calibrated* score.
     *
     * Token probability is not calibrated confidence, and converting one to the
     * other produces a number that looks like a probability and is not. An
     * engine without calibration reports null, and the UI shows no confidence
     * rather than a fabricated one.
     */
    readonly confidence: number | null;
}
/** One recognized region. */
export interface OcrBlock {
    readonly index: number;
    readonly text: string;
    readonly bbox: {
        readonly x: number;
        readonly y: number;
        readonly width: number;
        readonly height: number;
    };
    readonly languageTags: readonly string[];
    readonly scripts: readonly ScriptTag[];
    readonly direction: 'ltr' | 'rtl' | 'mixed' | 'unknown';
    readonly confidence: number | null;
}
/** What an OCR request is being asked to read. */
export interface OcrRoutingRequest {
    readonly workload: OcrWorkload;
    readonly scripts: readonly ScriptTag[];
    /** Prefer speed or accuracy. */
    readonly quality: 'fast' | 'balanced' | 'best';
    readonly hasGpu: boolean;
    readonly offlineOnly: boolean;
    readonly egressConsent: boolean;
}
/** Why an engine was not chosen. */
export interface RoutingExclusion {
    readonly engineId: string;
    readonly reason: string;
}
/** What the router decided, and why. */
export interface RoutingDecision {
    readonly engineId: string | null;
    /** One sentence, recorded in the receipt so a choice is auditable. */
    readonly reason: string;
    readonly excluded: readonly RoutingExclusion[];
}
/**
 * Choose an OCR engine.
 *
 * Deterministic filtering first, preference second — the model never picks
 * from a menu. Hardware, privacy and qualification decide what is *allowed*,
 * and only then does the quality profile choose among what is left. Every
 * exclusion is recorded, so "why did it use the light one?" has an answer.
 */
export declare function routeOcr(request: OcrRoutingRequest, engines: readonly TechnologyDescriptor[], qualification: readonly QualificationEntry[], health: ReadonlyMap<string, {
    readonly usable: boolean;
    readonly state: string;
}>): RoutingDecision;
/**
 * The lightweight local route.
 *
 * The default, because it runs everywhere. Not because it is the most accurate
 * — on clean documents it is not — but because a default that needs a GPU is
 * not a default.
 */
export declare const RAPID_OCR: TechnologyDescriptor;
/** The deterministic system fallback, for scripts the ONNX route cannot read. */
export declare const TESSERACT: TechnologyDescriptor;
/**
 * DeepSeek-OCR, the compatibility and comparison route.
 *
 * Pinned to a reviewed revision. `trust_remote_code` in its published
 * inference path is why `trust` is `isolated` and the runtime is a separate
 * process: a surprise in a model repository should cost a worker, not the
 * workspace.
 */
export declare const DEEPSEEK_OCR: TechnologyDescriptor;
/** DeepSeek-OCR2, the high-quality document candidate. */
export declare const DEEPSEEK_OCR2: TechnologyDescriptor;
/**
 * A cloud OCR route, behind an explicit consent.
 *
 * Present as a descriptor rather than as an integration: the point of having
 * it here is that the routing rules can *refuse* it. `requiresEgressConsent`
 * and `worksOffline: false` together mean `routeOcr` excludes it under an
 * offline-only profile and under a profile where cloud perception was never
 * agreed to — which is a different consent from holding a provider API key.
 *
 * No endpoint is baked in. A deployment that wants a cloud OCR route names its
 * own, and the route it names is what appears in the receipt.
 */
export declare const CLOUD_OCR: TechnologyDescriptor;
/**
 * Build a descriptor for a third-party OCR engine.
 *
 * The custom-provider seam. A capability author supplies what they know and
 * gets a descriptor that the same routing, health and licence rules apply to —
 * which is the point: a third-party engine is subject to every gate a built-in
 * one is, and cannot opt out of any of them.
 *
 * Two fields are forced regardless of what the caller passes. `trust` is
 * `third_party`, and `install.automatic` is false. Neither is something a
 * plugin gets to decide about itself.
 */
export declare function customOcrEngine(input: {
    readonly id: string;
    readonly displayName: string;
    readonly version: string;
    readonly runtime: TechnologyDescriptor['runtime'];
    readonly hardware: TechnologyDescriptor['hardware'];
    readonly privacy: TechnologyDescriptor['privacy'];
    readonly provenance: TechnologyDescriptor['provenance'];
    readonly resources: TechnologyDescriptor['resources'];
    readonly probeMethod: string;
    readonly testMethod: string;
    readonly endpoints?: readonly string[];
    readonly credentialReference?: string | null;
}): TechnologyDescriptor;
/**
 * Whether an engine's code may run in the host process.
 *
 * Only a built-in library. Everything else — third party, and anything marked
 * `isolated` because its inference path executes code fetched from a model
 * repository — runs in a worker, and this is what a caller checks before
 * choosing how to run it.
 */
export declare function mayRunInProcess(descriptor: TechnologyDescriptor): boolean;
/** The engines this build knows about. */
export declare const OCR_ENGINES: readonly TechnologyDescriptor[];
/**
 * Whether an engine's weights may be distributed or auto-fetched.
 *
 * A release gate. The repository licence is about the code; shipping or
 * downloading weights on someone's behalf needs the weight licence to have
 * been read, and `weightsLicenseReviewed` is the record that it was.
 */
export declare function mayDistributeWeights(descriptor: TechnologyDescriptor): boolean;
//# sourceMappingURL=ocr.d.ts.map