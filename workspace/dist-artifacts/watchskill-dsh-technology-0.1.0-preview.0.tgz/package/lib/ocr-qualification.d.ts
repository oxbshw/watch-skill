/**
 * Measuring an OCR engine, and refusing to report a number nobody measured.
 *
 * The framework exists in full here even though this machine has no GPU, and
 * that is deliberate rather than aspirational. The scoring, the matrix shape,
 * the aggregation and — most importantly — the rules about what may be
 * *claimed* are all testable without a model, using generated fixtures. What
 * cannot be produced here is a DeepSeek-OCR result, and no code path below can
 * manufacture one: a cell without a real run stays `NOT_TESTED`, which is a
 * different answer from `NOT_YET_QUALIFIED`.
 *
 * Two measurement decisions are worth stating.
 *
 * **Omission and hallucination are separate metrics.** Character error rate
 * folds them together, and they are not the same failure. An engine that drops
 * a line produces text a person will notice is short. An engine that invents a
 * plausible line produces text nobody can distinguish from a reading — which,
 * in a product whose whole claim is evidence, is the worse of the two by a
 * long way.
 *
 * **Nothing is averaged across scripts.** An engine that is excellent on Latin
 * and unusable on Arabic has a fine average and is unusable for half the
 * world. Every cell is one engine on one workload in one script, and there is
 * no function here that produces a single overall score.
 *
 * @module @watchskill/dsh-technology/ocr-qualification
 */
import type { OcrWorkload, QualificationEntry, ScriptTag } from './ocr.js';
/** One region a fixture expects to be read. */
export interface ExpectedRegion {
    readonly text: string;
    readonly bbox: {
        readonly x: number;
        readonly y: number;
        readonly width: number;
        readonly height: number;
    };
    /** Position in reading order, from zero. */
    readonly order: number;
}
/** One measurement case. */
export interface OcrFixture {
    readonly fixtureId: string;
    readonly workload: OcrWorkload;
    readonly script: ScriptTag;
    /** What the image says, exactly, in its original script. */
    readonly expectedText: string;
    readonly regions: readonly ExpectedRegion[];
    /** Digest of the image, so a result is attributable to an exact input. */
    readonly imageDigest: string;
}
/** What an engine produced for one fixture. */
export interface OcrObservation {
    readonly fixtureId: string;
    readonly text: string;
    readonly regions: readonly ExpectedRegion[];
    readonly latencyMs: number;
    readonly peakRamMb: number | null;
    readonly peakVramMb: number | null;
    /** True when the worker died producing this. */
    readonly crashed: boolean;
}
/**
 * Character error rate.
 *
 * Compared over Unicode code points rather than UTF-16 units, so a fixture in
 * an astral script is not scored as twice as long as it is. Not normalized,
 * not case-folded, not stripped of diacritics: an engine that drops Arabic
 * diacritics has changed the text, and a metric that folded them would score
 * that as perfect.
 */
export declare function characterErrorRate(expected: string, actual: string): number;
/** Word error rate, over whitespace-separated tokens. */
export declare function wordErrorRate(expected: string, actual: string): number;
/** Proportion of expected words reproduced exactly, in any position. */
export declare function wordAccuracy(expected: string, actual: string): number;
/** Intersection over union of two rectangles. */
export declare function regionIou(left: ExpectedRegion['bbox'], right: ExpectedRegion['bbox']): number;
/**
 * Layout F1 at an IoU threshold.
 *
 * A detected region counts as a match when it overlaps an expected one by at
 * least the threshold and no earlier detection already claimed it. Greedy
 * rather than optimal assignment: the difference is small in practice and the
 * greedy version is one function a reader can check.
 */
export declare function layoutF1(expected: readonly ExpectedRegion[], actual: readonly ExpectedRegion[], threshold?: number): number;
/**
 * How well reading order was preserved, as Kendall tau normalized to 0–1.
 *
 * Reading order is where an engine that scores well on characters can still be
 * useless: a two-column document read straight across produces every word and
 * no meaning.
 */
export declare function readingOrderScore(expected: readonly ExpectedRegion[], actual: readonly ExpectedRegion[]): number;
/**
 * Proportion of expected regions the engine did not produce at all.
 *
 * Kept apart from CER because a person can see that a result is short.
 */
export declare function omissionRate(expected: readonly ExpectedRegion[], actual: readonly ExpectedRegion[]): number;
/**
 * Proportion of produced regions that correspond to nothing expected.
 *
 * The metric that matters most in this product. An engine that invents a
 * plausible line produces text nobody can distinguish from a reading, and a
 * reading is what the rest of the system treats as evidence.
 */
export declare function hallucinationRate(expected: readonly ExpectedRegion[], actual: readonly ExpectedRegion[]): number;
/** Every metric, for one fixture. */
export interface MetricSet {
    readonly cer: number;
    readonly wer: number;
    readonly wordAccuracy: number;
    readonly layoutF1: number;
    readonly readingOrder: number;
    readonly omissionRate: number;
    readonly hallucinationRate: number;
    readonly latencyMs: number;
    readonly peakRamMb: number | null;
    readonly peakVramMb: number | null;
    readonly crashed: boolean;
}
/** Score one observation against its fixture. */
export declare function scoreObservation(fixture: OcrFixture, observation: OcrObservation): MetricSet;
/** What a cell has to clear to be qualified. */
export interface QualificationThresholds {
    readonly maxCer: number;
    readonly minWordAccuracy: number;
    readonly minLayoutF1: number;
    readonly minReadingOrder: number;
    /** Deliberately the tightest bound in the table. */
    readonly maxHallucinationRate: number;
    readonly maxOmissionRate: number;
}
/**
 * The default bar.
 *
 * Hallucination is held to a far tighter bound than any accuracy metric. An
 * engine that reads 92% of a page correctly is useful; an engine that invents
 * 5% of a page is dangerous, because the invented part looks exactly like the
 * read part to everything downstream.
 */
export declare const DEFAULT_THRESHOLDS: QualificationThresholds;
/** Which thresholds a metric set failed, in the words a report would use. */
export declare function thresholdFailures(metrics: MetricSet, thresholds?: QualificationThresholds): readonly string[];
/** One measured run: the fixture, what came out, and what it scored. */
export interface MeasuredRun {
    readonly fixture: OcrFixture;
    readonly metrics: MetricSet;
}
/** Where and when a measurement happened, so a number is attributable. */
export interface MeasurementContext {
    readonly measuredAt: string;
    /** A machine description. Never a build number — see the bench note in the engine repo. */
    readonly measuredOn: string;
}
/**
 * Turn measured runs into one matrix cell.
 *
 * The single most important line in this module is the first one: no runs
 * means `NOT_TESTED`, with empty metrics and null timestamps. There is no
 * fallback, no estimate, and no inheritance from a neighbouring script. A cell
 * nobody measured says nobody measured it.
 */
export declare function qualify(engineId: string, workload: OcrWorkload, script: ScriptTag, runs: readonly MeasuredRun[], context: MeasurementContext | null, thresholds?: QualificationThresholds): QualificationEntry;
/**
 * Build the whole matrix for one engine.
 *
 * Every workload × script cell exists, and the ones nobody ran are present and
 * `NOT_TESTED`. A matrix that omitted unmeasured cells would make an engine
 * measured on three things look like an engine measured on three things out of
 * three.
 */
export declare function buildMatrix(engineId: string, runs: readonly MeasuredRun[], context: MeasurementContext | null, thresholds?: QualificationThresholds): readonly QualificationEntry[];
/** How much of a matrix has actually been measured. */
export interface MatrixCoverage {
    readonly total: number;
    readonly measured: number;
    readonly qualified: number;
    readonly withLimitations: number;
    readonly notQualified: number;
    readonly notTested: number;
}
/** Count a matrix, so a claim of coverage is a number rather than an adjective. */
export declare function coverageOf(matrix: readonly QualificationEntry[]): MatrixCoverage;
/**
 * One line describing a matrix honestly.
 *
 * Leads with what was not measured. "Qualified on 6 of 120 cells" reads very
 * differently from "qualified", and the second is what a summary that led with
 * successes would amount to.
 */
export declare function describeCoverage(coverage: MatrixCoverage): string;
//# sourceMappingURL=ocr-qualification.d.ts.map