/**
 * Running an OCR engine that is not allowed anywhere near the workspace.
 *
 * DeepSeek-OCR's published inference path uses `trust_remote_code=True`. That
 * means loading the model executes Python fetched from a model repository, and
 * the only responsible place to do that is a process whose death costs
 * nothing. Not the DSH Host. Not the Watch Core main process. A worker.
 *
 * Isolation is therefore not a configuration option here, it is the shape of
 * the module: there is no in-process path, and no flag that produces one.
 *
 * Four things follow from that, and each is a rule rather than a nicety.
 *
 * **The pinned revision is checked, not assumed.** A worker announces the
 * model and revision it actually loaded, and a mismatch is a refusal. Pinning
 * a revision in a descriptor and never verifying it is a pin that documents an
 * intention rather than enforcing one — and "the model repository changed
 * under us" is exactly the failure that pinning exists to catch.
 *
 * **A crash is a crash, and it is not retried.** OCR has no side effects, so a
 * retry would be safe in the narrow sense; it is refused anyway, because a
 * worker that OOMs on a page will OOM on the same page again, and an automatic
 * retry turns one failure into a loop that looks like slowness. The state goes
 * to `degraded`, the reason says which signal or exit code, and routing takes
 * a different engine.
 *
 * **Cancellation is cooperative first and forcible second.** A cancel is sent,
 * a grace period passes, and then the process is killed by its own handle —
 * never by name. Killing by process name is how a supervisor takes down
 * somebody else's Python.
 *
 * **Nothing is downloaded.** The supervisor can describe an install plan; it
 * cannot perform one. Fetching multi-gigabyte weights on a user's behalf is a
 * decision they make, and the weight licence gate in `ocr.ts` has to clear
 * before it is even offerable.
 *
 * @module @watchskill/dsh-technology/ocr-worker
 */
import type { TechnologyDescriptor } from './descriptor.js';
/**
 * Where an engine is, in a vocabulary that keeps eight different things apart.
 *
 * The temptation is to collapse these into "works" and "does not work". Every
 * collapse loses something a person needs: `not_installed` and `unavailable`
 * differ in whether there is anything to do about it; `probed` and
 * `machine_tested` differ in whether anything has actually run; `degraded` and
 * `unavailable` differ in whether the next request might succeed.
 */
export type EngineState = 
/** Nothing on disk. */
'not_installed'
/** On disk, never started. */
 | 'installed'
/** A cheap check passed — the binary answers, the import resolves. */
 | 'probed'
/** A real recognition ran here and produced output. */
 | 'machine_tested'
/** A worker is up and answering. */
 | 'ready'
/** Up, but something is wrong: a crash, an OOM, a revision mismatch. */
 | 'degraded'
/** Cannot work on this machine, with a reason. */
 | 'unavailable'
/** Never checked. Not the same as any of the above. */
 | 'not_tested';
/** An engine's state, and why it is in it. */
export interface EngineHealth {
    readonly engineId: string;
    readonly state: EngineState;
    /** One sentence. Empty only for `ready`. */
    readonly detail: string;
    /** What the person can do. Empty when there is nothing. */
    readonly fix: string;
    /** The revision the worker reported, once one has. */
    readonly loadedRevision: string | null;
    /** ISO-8601 of the last state change. */
    readonly changedAt: string;
    /** Whether routing may select this engine. */
    readonly usable: boolean;
}
/** An engine that has never been looked at. */
export declare function untestedHealth(engineId: string, at: string): EngineHealth;
/** Whether a state permits routing to select the engine. */
export declare function isEngineUsable(state: EngineState): boolean;
/**
 * What a worker says when it comes up.
 *
 * `revision` is the load-bearing field. Everything else is diagnostics.
 */
export interface WorkerHello {
    readonly protocol: number;
    readonly model: string;
    readonly revision: string;
    readonly device: string;
    readonly vramGb: number | null;
}
/** One recognition request, as it crosses the process boundary. */
export interface WorkerRequest {
    readonly id: string;
    readonly method: 'recognize' | 'cancel' | 'shutdown';
    readonly params: Readonly<Record<string, unknown>>;
}
/** One response. */
export interface WorkerResponse {
    readonly id: string;
    readonly ok: boolean;
    readonly value?: unknown;
    readonly error?: {
        readonly code: string;
        readonly message: string;
    };
}
/** The protocol version this supervisor speaks. */
export declare const WORKER_PROTOCOL = 1;
/** How a worker is launched. */
export interface WorkerSpawn {
    readonly command: string;
    readonly args: readonly string[];
    readonly env?: Readonly<Record<string, string>>;
    readonly cwd?: string;
}
/** Deployment policy for one worker. */
export interface WorkerOptions {
    readonly descriptor: TechnologyDescriptor;
    readonly spawn: WorkerSpawn;
    /** How long to wait for the hello. */
    readonly startTimeoutMs: number;
    /** How long one recognition may take. */
    readonly requestTimeoutMs: number;
    /** How long a cancelled request has to stop before the process is killed. */
    readonly cancelGraceMs: number;
    /** Clock, injectable so tests are not timing-dependent. */
    readonly now?: () => string;
}
/** Why a worker call failed. */
export interface WorkerFailure {
    readonly code: 'not_started' | 'start_timeout' | 'revision_mismatch' | 'protocol_mismatch' | 'timeout' | 'cancelled' | 'crashed' | 'out_of_memory' | 'worker_error';
    readonly message: string;
    readonly fix: string;
    /** Whether trying the same request again could plausibly work. */
    readonly retryable: boolean;
}
/** The result of a worker call. */
export type WorkerResult<T> = {
    readonly ok: true;
    readonly value: T;
} | {
    readonly ok: false;
    readonly error: WorkerFailure;
};
/**
 * Supervises one OCR worker process.
 *
 * Deliberately owns exactly one child. A pool would be more efficient and
 * would also mean a crash takes down several in-flight requests whose failure
 * modes then have to be untangled; one process per supervisor keeps "which
 * request killed it" answerable.
 */
export declare class OcrWorker {
    private readonly options;
    private child;
    private hello;
    private buffer;
    private health;
    private readonly pending;
    private nextId;
    private stderr;
    constructor(options: WorkerOptions);
    /** The current health, including why. */
    status(): EngineHealth;
    /** The revision the running worker actually loaded. */
    loadedRevision(): string | null;
    /**
     * Start the worker and verify what it loaded.
     *
     * Three ways this refuses, and all three leave the process stopped:
     *
     * - it never says hello inside the start timeout;
     * - it speaks a different protocol;
     * - it loaded a revision other than the pinned one.
     *
     * The third is the one that matters most. A descriptor that pins a revision
     * and a supervisor that does not check it is a pin that records an intention
     * rather than enforcing one.
     */
    start(): Promise<WorkerResult<WorkerHello>>;
    /**
     * Recognize one image.
     *
     * On a crash the state goes to `degraded` and the failure says so; it is not
     * retried here, and `retryable` is false. A worker that ran out of memory on
     * a page will run out of memory on the same page, and an automatic retry
     * converts one visible failure into a loop that looks like slowness.
     */
    recognize(params: Readonly<Record<string, unknown>>, exec?: {
        readonly signal?: AbortSignal;
    }): Promise<WorkerResult<unknown>>;
    /** Stop the worker, cooperatively if it will. */
    stop(): Promise<void>;
    /** The worker's recent stderr, for a diagnostic panel. Bounded. */
    log(): string;
    private now;
    private setHealth;
    private fail;
    private send;
    private onData;
    private onLine;
    private helloResolver;
    private awaitHello;
    private onExit;
    /** Kill by handle. Never by name — that is somebody else's Python. */
    private terminate;
}
/** One step a person would have to take. */
export interface InstallStep {
    readonly description: string;
    /** The exact command, when there is one. Never run automatically. */
    readonly command: string | null;
    /** Bytes this step downloads, when known. */
    readonly downloadBytes: number | null;
}
/** What installing an engine would involve. */
export interface InstallPlan {
    readonly engineId: string;
    readonly steps: readonly InstallStep[];
    /** Refusals that must clear before this plan may even be offered. */
    readonly blockers: readonly string[];
    /** Whether anything here may be performed automatically. Always false. */
    readonly automatic: false;
}
/**
 * Describe what installing an engine would take.
 *
 * Describes; never performs. `automatic` is typed as the literal `false` so a
 * caller cannot branch on it becoming true one day without the type changing —
 * fetching multi-gigabyte weights on somebody's behalf is their decision, and
 * the weight-licence gate has to clear before it is even offerable.
 */
export declare function installPlan(descriptor: TechnologyDescriptor, environment: {
    readonly hasGpu: boolean;
    readonly vramGb: number | null;
}): InstallPlan;
//# sourceMappingURL=ocr-worker.d.ts.map