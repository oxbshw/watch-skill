/**
 * Triggers: a rule that notices something, and cannot do anything about it.
 *
 * A live observation runs for a long time and the interesting second is
 * usually not the one anybody is watching. So a trigger says "tell me when the
 * deploy log says failed", or "pin the moment the stream drops", and the
 * session keeps an eye out.
 *
 * The whole design question is what a trigger is allowed to *do*, and the
 * answer here is deliberately narrow: it may pin a moment, raise a
 * notification, or ask for a snapshot. It may not act. That is not a
 * limitation waiting to be lifted — {@link TriggerEffect} has no member that
 * touches the world, because a trigger fires on observed content, and a
 * trigger that could act would be a page deciding to click something by
 * putting the right words on screen.
 *
 * The second rule is a cooldown, which sounds like ergonomics and is not. A
 * text trigger on a scrolling log fires on every line, and a thousand
 * notifications is the same as none — except that it also buries the one that
 * mattered.
 *
 * @module @watchskill/dsh-live/triggers
 */
import type { LiveEvent, LiveEventKind, LiveSessionState } from './session.js';
/**
 * What firing does.
 *
 * Three members, all of them observation. There is no `act`, and adding one
 * would mean observed content could reach the operator loop without a person
 * in between.
 */
export type TriggerEffect = 
/** Keep the moment, so it survives the buffer bound. */
'pin'
/** Tell the person watching. */
 | 'notify'
/** Ask for a fresh snapshot, for a trigger about continuity. */
 | 'snapshot';
/** Every effect, so a UI can enumerate them and a test can check the set. */
export declare const TRIGGER_EFFECTS: readonly TriggerEffect[];
/** When a trigger fires. */
export type TriggerCondition = 
/** Any event of this kind. */
{
    readonly kind: 'event_kind';
    readonly eventKind: LiveEventKind;
}
/** Observed text containing a phrase. */
 | {
    readonly kind: 'text_contains';
    readonly phrase: string;
    readonly caseSensitive: boolean;
}
/** A capture gap longer than a threshold. */
 | {
    readonly kind: 'gap_longer_than';
    readonly ms: number;
}
/** Nothing observed for a while, which is itself information. */
 | {
    readonly kind: 'silence_for';
    readonly ms: number;
};
/** One rule. */
export interface LiveTrigger {
    readonly triggerId: string;
    /** What the person called it. */
    readonly label: string;
    readonly when: TriggerCondition;
    readonly effect: TriggerEffect;
    /** How long after firing before it may fire again. */
    readonly cooldownMs: number;
    readonly enabled: boolean;
}
/** One firing. */
export interface TriggerFiring {
    readonly triggerId: string;
    readonly effect: TriggerEffect;
    /** The event that caused it, when one did. */
    readonly eventSeq: number | null;
    readonly atMs: number;
    /** One line for the notification. Presentation only. */
    readonly reason: string;
}
/** When each trigger last fired, so a cooldown can be applied. */
export type TriggerCooldowns = ReadonlyMap<string, number>;
/**
 * Evaluate triggers against newly arrived events.
 *
 * Pure, and takes the cooldown map rather than holding one, so the same
 * function serves the live session and a replay of it. A trigger evaluator
 * with internal state would produce different firings on replay than it did
 * live, which would make a pinned moment unreproducible.
 */
export declare function evaluateTriggers(state: LiveSessionState, triggers: readonly LiveTrigger[], newEvents: readonly LiveEvent[], nowMs: number, cooldowns?: TriggerCooldowns): {
    readonly firings: readonly TriggerFiring[];
    readonly cooldowns: TriggerCooldowns;
};
/**
 * Whether a firing may cause anything outside the session.
 *
 * Always false. Present as a function rather than as a comment so a caller
 * that is about to route a firing somewhere has something to check, and so a
 * test can assert the answer for every effect the type allows.
 */
export declare function mayAct(_firing: TriggerFiring): false;
/**
 * One line describing what a trigger will do, for the panel that creates it.
 *
 * Says the effect in the words of what it does rather than its name, because
 * "pin" is a word somebody could read as "act on".
 */
export declare function describeTrigger(trigger: LiveTrigger): string;
//# sourceMappingURL=triggers.d.ts.map