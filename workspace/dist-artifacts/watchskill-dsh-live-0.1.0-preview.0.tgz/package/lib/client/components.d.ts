/**
 * The Live surface.
 *
 * The header is deliberately busy. A live view's job is to be trustworthy
 * about time, and that means the clocks, the latency, the connection state and
 * the continuity line are all present at once rather than behind a disclosure.
 * The moment one of them is hidden, the surface starts implying a continuity
 * it has not checked.
 *
 * @module @watchskill/dsh-live/components
 */
import type { ReactNode } from 'react';
import { type LiveEvent, type LiveSessionState } from '../session.js';
/** Props for {@link LiveHeader}. */
export interface LiveHeaderProps {
    readonly state: LiveSessionState;
}
/**
 * Session, media and wall clocks, side by side.
 *
 * Three readings rather than one, because they answer three questions and
 * disagree constantly during a live observation. A single "time" field would
 * be right about one of them and quietly wrong about the other two.
 */
export declare function LiveHeader({ state }: LiveHeaderProps): ReactNode;
/** Props for {@link LiveEventRow}. */
export interface LiveEventRowProps {
    readonly event: LiveEvent;
    readonly onSelect: (event: LiveEvent) => void;
}
/**
 * One observed event.
 *
 * A gap draws as a gap — dashed, glyphed and labelled — and is never
 * collapsed into the events around it.
 */
export declare function LiveEventRow({ event, onSelect }: LiveEventRowProps): ReactNode;
/** Props for {@link LiveSurface}. */
export interface LiveSurfaceProps {
    readonly state: LiveSessionState;
    readonly onStart: () => void;
    readonly onStop: (finalize: boolean) => void;
    readonly onAsk: (question: string) => void;
    readonly onSelect: (event: LiveEvent) => void;
    readonly onPin: () => void;
}
/**
 * The Live mode body.
 *
 * `Resnapshot needed` is rendered as a banner rather than a toast. A transient
 * notification for "your view of this is not continuous" is a notification
 * that will be missed exactly when it matters.
 */
export declare function LiveSurface(props: LiveSurfaceProps): ReactNode;
//# sourceMappingURL=components.d.ts.map