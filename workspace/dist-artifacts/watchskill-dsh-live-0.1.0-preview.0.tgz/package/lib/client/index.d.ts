/**
 * The Live surface, registered into DSH's slots.
 *
 * @module @watchskill/dsh-live/client
 */
import type { Context } from '@deepseek-ai/cordis';
export * from './components.js';
export * from '../session.js';
/** Services this half needs before it can register anything. */
export declare const inject: string[];
/** Register the Live mode body. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map