/**
 * `watchMemory` — durable, correctable, scoped memory for a Harness workspace.
 *
 * The service is deliberately thin. The rules live in `records.ts`, the
 * authority in `ledger.ts`, the selection in `compiler.ts` and the human view
 * in `projector.ts`; this is the seam that mounts them into Cordis and holds
 * the ordering those pieces assume.
 *
 * Three behaviors define it, and all three are about a person keeping control:
 *
 * - **A correction takes effect on the next turn.** Not eventually, not after a
 *   re-index. `correct` supersedes in the same write and the next compile sees
 *   it, because a preference someone has already corrected being applied again
 *   is the failure that makes people stop correcting.
 * - **Forget removes, it does not hide.** The ledger folds a tombstoned id out
 *   of existence and every projection is rebuilt from that fold.
 * - **Nothing high-impact activates itself.** Whatever the confidence, and
 *   whatever it appears the person asked for.
 *
 * @module @watchskill/dsh-memory
 */
import { type Context, Service } from '@deepseek-ai/cordis';
import s from '@deepseek-ai/schemastery';
import type { AdmissionDecision, MemoryEvent, MemoryKind, MemoryMode, MemoryOrigin, MemoryRecord, MemoryScope, ScopeContext } from './records.js';
import { MemoryLedger } from './ledger.js';
import type { ContextPacket, CompileOptions } from './compiler.js';
export type * from './records.js';
export * from './records.js';
export { MemoryLedger } from './ledger.js';
export * from './compiler.js';
export * from './projector.js';
export * from './tools.js';
export * from './learning.js';
export * from './replay.js';
/** Deployment configuration for memory. */
export interface Config {
    /** What this profile permits. `off` writes and recalls nothing. */
    readonly mode: MemoryMode;
    /** Directory for the ledger and the Markdown projections. */
    readonly directory: string;
    /** Confidence at or above which an inferred, low-impact memory acts. */
    readonly inferredThreshold: number;
    /** Hard ceiling on what memory may cost one turn. */
    readonly tokenBudget: number;
    /** Write `taste.md` and friends whenever memory changes. */
    readonly writeProjections: boolean;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Durable, correctable memory scoped to a user, workspace or project. */
        watchMemory: WatchMemoryService;
    }
}
/** What a caller supplies to remember something. */
export interface MemoryCandidate {
    readonly kind: MemoryKind;
    readonly content: string;
    readonly origin: MemoryOrigin;
    readonly subjectScope: MemoryScope;
    readonly scopeId: string;
    readonly confidence?: number;
    readonly sourceRefs?: readonly string[];
    readonly evidenceRefs?: readonly string[];
    readonly sensitivity?: MemoryRecord['sensitivity'];
    readonly locale?: string | null;
}
/** What happened to a candidate. */
export interface RememberResult {
    readonly stored: boolean;
    readonly memoryId: string | null;
    readonly status: MemoryRecord['status'] | null;
    /** Why it was refused, or why it is proposed rather than active. */
    readonly reason: string;
    readonly admission: AdmissionDecision;
}
/** One recorded reason a memory reached a turn's context. */
export interface InjectionReason {
    readonly at: string;
    readonly sessionId: string | null;
    readonly reason: string;
    readonly tokenEstimate: number;
}
/** A portable copy of what one scope can see. */
export interface MemoryExport {
    readonly exportedAt: string;
    readonly scope: ScopeContext;
    readonly mode: MemoryMode;
    readonly records: readonly MemoryRecord[];
    readonly events: readonly MemoryEvent[];
}
/** Durable memory as a Cordis service. */
export declare class WatchMemoryService extends Service {
    private readonly config;
    /** Loader validation for the memory policy. */
    static Config: s<Config>;
    private readonly ledger;
    constructor(ctx: Context, config: Config);
    /** What this profile permits. */
    mode(): MemoryMode;
    /**
     * Consider remembering something.
     *
     * Returns rather than throws when a candidate is refused: a refusal carries
     * an explanation the caller should relay, and an exception would strip that
     * down to a generic failure.
     */
    remember(candidate: MemoryCandidate, options?: {
        readonly userAuthenticated?: boolean;
        readonly actor?: 'user' | 'agent' | 'system';
    }): RememberResult;
    /**
     * Record a correction, superseding what it contradicts.
     *
     * The supersession happens in the same call, so the very next compile sees
     * the new value and none of the old ones. Anything slower — a queue, a
     * rebuild, a nightly pass — means the agent applies a preference the person
     * has already corrected, at least once, and that is the specific experience
     * that teaches people correcting is pointless.
     */
    correct(candidate: MemoryCandidate, options?: {
        readonly userAuthenticated?: boolean;
    }): RememberResult;
    /** Affirm a proposed or active memory. */
    confirm(memoryId: string): boolean;
    /** Mark a memory contradicted. It stops acting but stays readable. */
    dispute(memoryId: string, reason: string): boolean;
    /**
     * Forget a memory.
     *
     * A tombstone in the ledger, then every projection rebuilt from the fold.
     * The record does not come back on replay, does not appear in `taste.md`,
     * and is not in the next context packet — because there is one fold and
     * everything reads it, rather than a delete plus a list of caches somebody
     * has to remember to clear.
     */
    forget(memoryId: string): boolean;
    /**
     * Decline a proposal.
     *
     * Distinct from forgetting, and only valid on something still `proposed`.
     * Rejecting an active memory would be a way to remove it without the word
     * "forget" appearing anywhere, and the ledger would then record a deletion
     * as a decline. It tombstones, because a suggestion somebody said no to must
     * not still be sitting in the list they said no to it from.
     */
    reject(memoryId: string, reason: string): boolean;
    /**
     * Move a memory to a different scope.
     *
     * The guard is the point. Personal taste is private by default, so widening
     * a preference or anything sensitive into a shared workspace scope needs the
     * person to say so in this call rather than in a setting they changed once.
     * Narrowing is always allowed: pulling something back out of a shared scope
     * should never need permission.
     */
    moveScope(memoryId: string, target: {
        readonly subjectScope: MemoryScope;
        readonly scopeId: string;
    }, options?: {
        readonly shareExplicitly?: boolean;
    }): {
        readonly moved: boolean;
        readonly reason: string;
    };
    /**
     * Export what one scope can see.
     *
     * Built from the same fold every other reader uses, which is what makes the
     * guarantee hold: a forgotten memory is absent from the export for the same
     * reason it is absent from the next context packet, rather than because the
     * export remembered to filter it.
     *
     * Sensitive content is withheld unless asked for. The record still appears —
     * an export that silently omitted rows would misrepresent what is held — but
     * its content is replaced by a marker.
     */
    export(scope: ScopeContext, options?: {
        readonly includeSensitive?: boolean;
        readonly includeEvents?: boolean;
    }): MemoryExport;
    /**
     * Why a memory was retrieved, in the words the compiler used.
     *
     * Read out of the ledger's own `context.injected` events rather than
     * recomputed, so the answer is what actually happened on that turn and not
     * what would happen if the same question were asked now.
     */
    whyRemembered(memoryId: string, sessionId?: string): readonly InjectionReason[];
    /** Every event in the ledger, for the Memory timeline surface. */
    events(sinceSeq?: number): readonly MemoryEvent[];
    /** Everything visible from a scope, whatever its status. For the UI. */
    list(scope: ScopeContext): readonly MemoryRecord[];
    /** One record's full history, for "why does it think that?". */
    history(memoryId: string): ReturnType<MemoryLedger['history']>;
    /**
     * Build the memory packet for one turn.
     *
     * Records the inclusion trace in the ledger as it goes, so "Why remembered?"
     * can answer for a turn that has already finished.
     */
    compile(scope: ScopeContext, options?: Partial<CompileOptions>): ContextPacket;
    /** The packet as a system-prompt section, or empty when there is nothing. */
    render(scope: ScopeContext, options?: Partial<CompileOptions>): string;
    /** Event counts, for the memory dashboard and diagnostics. */
    stats(): Readonly<Record<string, number>>;
    /** Fill in everything a candidate did not state. */
    private materialize;
    /** Regenerate every Markdown projection from the ledger. */
    private rebuildProjections;
}
export default WatchMemoryService;
//# sourceMappingURL=index.d.ts.map