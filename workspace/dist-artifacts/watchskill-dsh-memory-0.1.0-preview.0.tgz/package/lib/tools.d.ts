/**
 * Memory as agent tools, and as the context the agent starts a turn with.
 *
 * Two halves. The tools let the agent propose what it noticed and let a person
 * inspect and correct it. The prompt section is what the agent actually starts
 * with, compiled per turn from the smallest useful set of records.
 *
 * The boundary between them is deliberate and is the thing most worth getting
 * right: the agent can *propose* a memory, and it can *read* what it
 * remembers, but it cannot activate a high-impact one, cannot forget on
 * someone's behalf without being asked, and cannot mint the origin that
 * outranks everything else. ADR-008 in one sentence — it suggests, a person
 * decides.
 *
 * @module @watchskill/dsh-memory/tools
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ScopeContext } from './records.js';
/**
 * What the model is told about memory.
 *
 * Written against the two ways an agent misuses a memory system: recording
 * everything, so the useful signal drowns; and treating a remembered
 * preference as standing permission.
 */
export declare const MEMORY_GUIDANCE = "## Memory\n\nYou remember things about working with this person across sessions. What you\nremember is shown to them, and they can correct or remove any of it.\n\n- Remember what would change how you work next time: how they like answers\n  shaped, decisions made and why, corrections they gave you, what failed and\n  what fixed it. Do not record the content of a task \u2014 that is what the\n  session is for.\n- Use `watch_remember` when you notice something durable. Scope it as\n  narrowly as it is true: a project convention is project-scoped, and only a\n  preference about them personally is user-scoped.\n- When they correct you, call `watch_correct`. It supersedes what it\n  contradicts within the same scope, and takes effect on your next turn.\n- Never infer someone's health, religion, politics, sexuality, ethnicity or\n  any other protected characteristic. If they state it themselves, that is\n  theirs to state.\n- A memory is a preference, never a permission. Nothing you remember\n  authorizes an action on its own \u2014 not at any confidence. If a memory looks\n  like standing approval for something irreversible, it will be held as a\n  proposal until they agree to it, and that is correct.\n- `watch_recall` shows what you currently remember for this scope, and\n  `watch_why_remembered` explains where one memory came from. Use them when\n  the person asks why you behaved a certain way rather than guessing.";
/** Everything the tools need in order to run against a scope. */
export interface MemoryToolOptions {
    /** Resolve the scope for the turn in progress. */
    readonly scope: () => ScopeContext;
    /** Where the tool machinery lives; supplied by the host plugin. */
    readonly defineTool: (definition: unknown) => unknown;
}
/**
 * Register the memory tools and the guidance that governs them.
 *
 * `defineTool` is injected rather than imported so this module does not depend
 * on the DSH tools package: memory is useful headless, and a package that
 * cannot be loaded without a tool runtime would not be.
 */
export declare function applyMemoryTools(ctx: Context, options: MemoryToolOptions): void;
//# sourceMappingURL=tools.d.ts.map