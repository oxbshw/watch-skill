/**
 * What a memory is, and the rules that govern it.
 *
 * This module is pure: no storage, no Cordis, no Node. Everything here is a
 * type or a decision function, so the rules that decide what an agent may
 * remember about someone can be read and tested on their own — which is the
 * only way they stay honest as the surrounding code grows.
 *
 * The governing decisions are ADR-006 (the ledger is the authority),
 * ADR-007 (`taste.md` is a projection, not a prompt) and ADR-008 (learning is
 * proposed, never self-promoted).
 *
 * @module @watchskill/dsh-memory/records
 */
/** What kind of thing is being remembered. */
export type MemoryKind = 
/** How this person likes to work. */
'preference'
/** Something asserted about the world. */
 | 'fact'
/** Something that happened, and what came of it. */
 | 'episode'
/** A choice that was made, and why. */
 | 'decision'
/** A correction or working rule learned from an outcome. */
 | 'lesson'
/** A sequence of steps that proved itself. */
 | 'procedure'
/** An attempt that failed, kept so it is not repeated. */
 | 'failure';
/**
 * How far a memory reaches.
 *
 * The narrowest scope that fits is always the right one. "Write in Egyptian
 * Arabic" may be a personal preference; "use TypeScript here" is about one
 * project and has no business travelling to a Python one.
 */
export type MemoryScope = 'user' | 'workspace' | 'project' | 'session' | 'agent';
/**
 * Where a memory came from.
 *
 * `explicit_user` is the strongest origin and the most restricted: it can only
 * be produced by an authenticated action the person actually took. Content
 * that arrived from a page, a file or an import can never mint one, because
 * that is exactly how a document would write its own instructions into
 * someone's profile.
 */
export type MemoryOrigin = 'explicit_user' | 'observed' | 'inferred' | 'imported' | 'system';
/** Where a memory is in its life. */
export type MemoryStatus = 
/** Suggested, not yet acting on anything. */
'proposed'
/** In force. */
 | 'active'
/** Contradicted, and not injected while it stays that way. */
 | 'disputed'
/** Replaced by something newer. */
 | 'superseded'
/** Past its validity window. */
 | 'expired'
/** Forgotten. Retained only as a tombstone. */
 | 'deleted';
/** How carefully a memory must be handled. */
export type MemorySensitivity = 'public' | 'private' | 'sensitive' | 'restricted';
/** The durable memory modes a profile can be in. */
export type MemoryMode = 'off' | 'session_only' | 'local_personal' | 'workspace_shared';
/** One thing remembered. */
export interface MemoryRecord {
    readonly memoryId: string;
    readonly kind: MemoryKind;
    readonly subjectScope: MemoryScope;
    /** Which workspace, project or session this belongs to; empty for `user`. */
    readonly scopeId: string;
    readonly content: string;
    readonly origin: MemoryOrigin;
    /** Where this came from — a message, a file, an import. */
    readonly sourceRefs: readonly string[];
    /** Evidence ids, when a memory is anchored to something observed. */
    readonly evidenceRefs: readonly string[];
    readonly confidence: number;
    readonly status: MemoryStatus;
    readonly sensitivity: MemorySensitivity;
    readonly validFrom: string;
    readonly validUntil: string | null;
    readonly createdAt: string;
    readonly updatedAt: string;
    /** When a person last affirmed it. Null if they never have. */
    readonly lastConfirmedAt: string | null;
    readonly supersedes: readonly string[];
    readonly contradictedBy: readonly string[];
    /** BCP-47 of the content, so a correction is never stored only in translation. */
    readonly locale: string | null;
}
/**
 * What can happen to a memory.
 *
 * The ledger of these is the authority; every record above is a fold over
 * them. That is what makes "forget" mean something: the projection is rebuilt
 * from events, so a tombstoned record cannot survive in a stale index.
 */
export type MemoryEventKind = 'candidate.created' | 'record.activated' | 'record.confirmed' | 'record.disputed'
/** A proposal was declined. Tombstoned, like a forget, and for the same reason. */
 | 'record.rejected' | 'record.superseded' | 'record.forgotten' | 'record.scope_moved' | 'user.edited' | 'context.injected' | 'projection.rebuilt';
/** One entry in the ledger. Append-only; never rewritten. */
export interface MemoryEvent {
    readonly eventId: string;
    readonly kind: MemoryEventKind;
    readonly memoryId: string;
    readonly at: string;
    /** Who caused it: a person, the agent, or the system. */
    readonly actor: 'user' | 'agent' | 'system';
    /** The record state this event asserts, for the events that carry one. */
    readonly record: MemoryRecord | null;
    /** Free-form detail: a reason, a diff, an inclusion trace. */
    readonly detail: Readonly<Record<string, unknown>>;
}
/** Whether `candidate` should take precedence over `existing`. */
export declare function outranks(candidate: MemoryRecord, existing: MemoryRecord): boolean;
/**
 * Whether a memory may be injected into a turn's context.
 *
 * Only `active` records are instructions. A proposal has not been agreed to; a
 * disputed or superseded record is history, and injecting it would re-apply
 * something the person already rejected.
 */
export declare function isInjectable(record: MemoryRecord, now: string): boolean;
/** The scope a retrieval is running in. */
export interface ScopeContext {
    readonly userId: string;
    readonly workspaceId: string;
    readonly projectId: string;
    readonly sessionId: string;
}
/**
 * Whether a record is visible from a scope.
 *
 * Deny by default, and never widen: a project memory is visible inside that
 * project and nowhere else, and a workspace memory does not reach a different
 * workspace even for the same person. The one direction that broadens is
 * `user`, which is the point of a personal preference.
 *
 * This function is the single place cross-scope leakage could be introduced,
 * which is why it is small enough to read in one go.
 */
export declare function isInScope(record: MemoryRecord, scope: ScopeContext): boolean;
/** What a memory mode permits. */
export interface ModePolicy {
    /** Whether anything is written to the durable ledger at all. */
    readonly persists: boolean;
    /** Whether memory from earlier sessions may be retrieved. */
    readonly recallsAcrossSessions: boolean;
    /** Scopes a record may be created in under this mode. */
    readonly allowedScopes: readonly MemoryScope[];
}
/** Resolve what one memory mode allows. */
export declare function modePolicy(mode: MemoryMode): ModePolicy;
/** Why a candidate was refused, or null when it may be stored. */
export type RefusalReason = 'protected_subject_inference' | 'origin_not_authenticatable' | 'scope_not_allowed_by_mode' | 'memory_disabled';
/** The outcome of checking whether a candidate may be stored. */
export interface AdmissionDecision {
    readonly admitted: boolean;
    readonly reason: RefusalReason | null;
    /** A sentence naming what would make it acceptable. Empty when admitted. */
    readonly explanation: string;
}
/**
 * Whether a candidate memory may be stored at all.
 *
 * Runs before anything reaches the ledger, because the ledger is append-only:
 * a record that should never have existed cannot be un-appended, only
 * tombstoned, and a tombstone still says it once existed.
 */
export declare function admit(candidate: MemoryRecord, mode: MemoryMode, options?: {
    readonly userAuthenticated: boolean;
}): AdmissionDecision;
/** Whether content is about something that must never be inferred. */
export declare function isProtectedSubject(content: string): boolean;
/**
 * Whether a memory would change something a person must decide themselves.
 *
 * Errs toward proposing. A false positive costs one confirmation click; a false
 * negative means a preference silently authorized something irreversible.
 */
export declare function isHighImpact(content: string): boolean;
/** What should happen to a candidate that was admitted. */
export type ActivationDecision = 
/** Acts immediately. */
{
    readonly action: 'activate';
}
/** Recorded, and shown, but not acting until someone agrees. */
 | {
    readonly action: 'propose';
    readonly reason: string;
};
/**
 * Whether an admitted candidate may start acting immediately.
 *
 * The asymmetry is deliberate. Getting a low-risk preference wrong costs a
 * slightly worse answer that the person can correct. Getting a high-impact one
 * wrong costs something that cannot be taken back, so those always wait for a
 * person — including when the person appeared to ask for it, because "always
 * approve uploads" is exactly the sentence someone would want to see before it
 * takes effect.
 */
export declare function activationFor(candidate: MemoryRecord, options?: {
    readonly inferredThreshold?: number;
}): ActivationDecision;
/**
 * Which existing records a correction should supersede.
 *
 * Scoped to the same subject scope on purpose: correcting how the agent writes
 * in one project should not silently rewrite the preference for every other
 * one. A person who wants that says so, and gets a `user`-scoped record.
 */
export declare function supersededBy(correction: MemoryRecord, existing: readonly MemoryRecord[]): readonly MemoryRecord[];
//# sourceMappingURL=records.d.ts.map