/**
 * The Context Compiler: what the agent is told, and why.
 *
 * The temptation with memory is to inject all of it and let the model sort it
 * out. That fails in three ways at once — it costs tokens on every turn, it
 * lets stale and disputed records act as instructions, and it makes
 * personalization unexplainable, because nobody can say which remembered thing
 * caused a given behavior.
 *
 * So this selects the smallest useful packet and records why each item is in
 * it. The inclusion trace is not diagnostics: it is what "Why remembered?"
 * shows a person, and what lets them correct the specific record that made the
 * agent behave the way it did.
 *
 * @module @watchskill/dsh-memory/compiler
 */
import type { MemoryRecord, ScopeContext } from './records.js';
/** One memory selected for a turn, with the reason it was selected. */
export interface ContextItem {
    readonly memoryId: string;
    readonly content: string;
    readonly kind: MemoryRecord['kind'];
    readonly scope: MemoryRecord['subjectScope'];
    readonly origin: MemoryRecord['origin'];
    readonly confidence: number;
    /** Roughly what this costs to include. */
    readonly tokenEstimate: number;
    /** One sentence a person can read. Never empty. */
    readonly reason: string;
}
/** What the compiler produced, and what it left out. */
export interface ContextPacket {
    readonly items: readonly ContextItem[];
    readonly tokenEstimate: number;
    /** Records that were in scope and eligible but did not fit the budget. */
    readonly droppedForBudget: readonly string[];
    /**
     * True when personalization was skipped entirely.
     *
     * A hard budget must degrade to *no* memory rather than to an arbitrary
     * half of it: a packet trimmed at random is worse than none, because the
     * agent then acts on a partial picture nobody chose.
     */
    readonly fellBackToNone: boolean;
}
/** What the compiler is allowed to spend and prefer. */
export interface CompileOptions {
    /** Hard ceiling. Nothing is included past it. */
    readonly tokenBudget: number;
    /** Words in the current task, used to prefer what is relevant to it. */
    readonly task: string;
    /** How many items may come from any one scope, so one does not crowd out. */
    readonly perScopeLimit: number;
}
/**
 * Estimate the token cost of a string.
 *
 * Four characters per token is the usual rough figure for Latin text and
 * over-counts for CJK, which is the safe direction: over-estimating stops
 * early, and under-estimating silently blows the budget the caller set.
 */
export declare function estimateTokens(text: string): number;
/**
 * Choose the smallest useful set of memories for one turn.
 *
 * @param candidates - records already filtered to this scope and injectable.
 *   This function deliberately does not filter by scope itself: doing it in
 *   two places is how one of them eventually stops matching the other.
 */
export declare function compileContext(candidates: readonly MemoryRecord[], _scope: ScopeContext, options?: Partial<CompileOptions>): ContextPacket;
/**
 * Render a packet for a system-prompt section.
 *
 * The framing matters as much as the content. These are things the agent knows
 * about someone, and they are labelled that way — including the reminder that
 * they are preferences rather than permissions, because the one failure mode
 * worth engineering against is a remembered preference being read as
 * authorization.
 */
export declare function renderContext(packet: ContextPacket): string;
//# sourceMappingURL=compiler.d.ts.map