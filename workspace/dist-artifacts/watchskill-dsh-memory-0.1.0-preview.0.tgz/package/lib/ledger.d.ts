/**
 * The MemoryEvent ledger.
 *
 * ADR-006 makes this the authority. Every record the rest of the system sees
 * is a fold over these events, and the Markdown projections and search indexes
 * are caches that can be deleted and rebuilt from here.
 *
 * That is not architectural taste — it is what makes *forget* mean something.
 * If records were the stored truth and projections were maintained alongside
 * them, forgetting would be a delete plus a set of cleanups that someone has
 * to remember to write, and the one that gets missed is where the forgotten
 * thing survives. Here there is one write path and one fold, so a tombstoned
 * record cannot come back through a stale index.
 *
 * @module @watchskill/dsh-memory/ledger
 */
import type { MemoryEvent, MemoryRecord, ScopeContext } from './records.js';
/** How the ledger reports what it did, without exposing its storage. */
export interface AppendResult {
    readonly eventId: string;
    readonly seq: number;
}
/** An append-only store of memory events, with a fold to current records. */
export declare class MemoryLedger {
    private readonly db;
    /**
     * The fold, kept between calls and advanced incrementally.
     *
     * A benchmark found `compile()` at a 231ms p95 on a 500-record ledger
     * against a 50ms budget, and the whole of it was here: every caller of
     * `records()` re-read and re-parsed the entire event table, and `record()`
     * called `records()` for a single lookup.
     *
     * An append-only log is exactly the shape where this is safe. New events
     * only ever arrive after the ones already folded, so the cache advances by
     * reading `events(sinceSeq)` rather than by being invalidated — and there is
     * no update path that could make an already-folded event wrong, because
     * there is no update path at all.
     */
    private folded;
    private tombstoned;
    private foldedUpToSeq;
    /**
     * @param path - the database file, or `:memory:` for an ephemeral ledger.
     *   `session_only` mode uses the latter, which is what makes that mode a
     *   property of the storage rather than a rule someone has to enforce.
     */
    constructor(path: string);
    /** Append one event. The only write path there is. */
    append(event: Omit<MemoryEvent, 'eventId'> & {
        readonly eventId?: string;
    }): AppendResult;
    /** Read the whole ledger in order. Used to rebuild every projection. */
    events(sinceSeq?: number): readonly MemoryEvent[];
    /** Every event about one memory, oldest first. Its whole history. */
    history(memoryId: string): readonly MemoryEvent[];
    /**
     * Fold the ledger into the records that currently exist.
     *
     * A forgotten memory is absent from the result entirely — not present with a
     * `deleted` status, which would leave every caller responsible for filtering
     * it and would eventually be forgotten by one of them.
     */
    records(): readonly MemoryRecord[];
    /**
     * Read whatever has arrived since the last fold and apply it.
     *
     * The same rules as the original whole-log fold, applied to a suffix. The
     * tombstone set has to persist across calls for the "never comes back" rule
     * to survive: a `record.forgotten` in an earlier batch must still suppress a
     * record carried by an event in a later one.
     */
    private advanceFold;
    /** Events after a sequence, carrying their sequence for the fold cursor. */
    private eventsWithSeq;
    /** One current record, or null when it never existed or was forgotten. */
    record(memoryId: string): MemoryRecord | null;
    /**
     * Records visible from one scope and eligible to act.
     *
     * Both filters, always, in this order. Scope decides what may be seen at
     * all; injectability decides what may act. Splitting them lets the Memory
     * surface show a person their disputed and proposed records without any of
     * that reaching a model's context.
     */
    injectable(scope: ScopeContext, now: string): readonly MemoryRecord[];
    /** Everything visible from a scope, whatever its status. For the UI. */
    visible(scope: ScopeContext): readonly MemoryRecord[];
    /** Whether an id has been tombstoned. */
    isForgotten(memoryId: string): boolean;
    /** Count events by kind, for diagnostics and the memory dashboard. */
    counts(): Readonly<Record<string, number>>;
    /** Release the handle. Safe to call twice. */
    close(): void;
}
//# sourceMappingURL=ledger.d.ts.map