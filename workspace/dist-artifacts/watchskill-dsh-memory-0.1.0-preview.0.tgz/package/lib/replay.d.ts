/**
 * Replaying a candidate against fixtures, to produce a number instead of an
 * opinion.
 *
 * ADR-008 makes promotion conditional on a {@link CandidateEvaluation}, and
 * until now the caller supplied one. That was a real gap rather than a
 * simplification: a governance rule whose evidence is provided by whoever wants
 * the promotion is a rule that grants itself.
 *
 * So this is the harness. It takes a set of cases somebody approved, runs them
 * with and without the candidate applied, and reports four deltas. Three of
 * them are ordinary trade-offs. The fourth is not:
 *
 * > A safety violation is not tradeable against anything.
 *
 * A candidate that improves quality, halves latency and introduces one safety
 * violation is refused. That is why `safetyViolations` is a separate axis
 * rather than a weight in a score — a weighted score is a machine for arguing
 * that a regression was worth it.
 *
 * The fixture set is digested and the digest travels with the evaluation, so
 * "it was evaluated" is a checkable claim rather than a state flag. Re-running
 * a candidate against a *different* fixture set produces a different digest,
 * and `canPromote` can tell.
 *
 * @module @watchskill/dsh-memory/replay
 */
import type { CandidateEvaluation, LearningCandidate, MetricDelta } from './learning.js';
/** One case a candidate is replayed against. */
export interface ReplayCase {
    readonly caseId: string;
    /** What the agent was asked. */
    readonly prompt: string;
    /**
     * What a correct answer contains.
     *
     * Substrings rather than an exact match: a case that demanded byte equality
     * would fail on every rewording and stop being run.
     */
    readonly expects: readonly string[];
    /** Anything whose presence is a safety violation, not a quality miss. */
    readonly forbids: readonly string[];
}
/** What running one case produced. */
export interface ReplayOutcome {
    readonly caseId: string;
    readonly text: string;
    readonly latencyMs: number;
    readonly costUnits: number;
}
/**
 * How a case is run.
 *
 * Injected rather than imported: the thing being replayed is an agent, and an
 * evaluation harness that owned one would be a harness nobody could run in a
 * test. The caller supplies a runner that applies — or does not apply — the
 * candidate.
 */
export type CaseRunner = (replayCase: ReplayCase, options: {
    readonly withCandidate: boolean;
}) => ReplayOutcome | Promise<ReplayOutcome>;
/** A digest over the fixture set, so an evaluation names what it ran on. */
export declare function fixtureSetDigest(cases: readonly ReplayCase[]): string;
/** How one outcome scored against its case. */
export interface CaseScore {
    readonly caseId: string;
    /** Fraction of expectations met, 0 to 1. */
    readonly quality: number;
    /** How many forbidden things appeared. Any is too many. */
    readonly violations: number;
    readonly latencyMs: number;
    readonly costUnits: number;
}
/**
 * Score one outcome.
 *
 * Case-insensitive substring matching, because the cases are written as "the
 * answer should mention the error code" rather than as a transcript. An
 * evaluation that demanded exact text would measure phrasing rather than
 * behaviour.
 */
export declare function scoreCase(replayCase: ReplayCase, outcome: ReplayOutcome): CaseScore;
/** Both halves of a replay, kept so a reviewer can look at the cases. */
export interface ReplayReport {
    readonly evaluation: CandidateEvaluation;
    readonly baseline: readonly CaseScore[];
    readonly candidate: readonly CaseScore[];
    /** Cases where the candidate introduced a violation the baseline did not. */
    readonly newViolations: readonly string[];
    /** Cases where the candidate removed one the baseline had. */
    readonly fixedViolations: readonly string[];
    /** Cases where quality dropped. */
    readonly regressions: readonly string[];
    /**
     * The unadjusted counts, for a reviewer reading the report.
     *
     * `evaluation.safetyViolations` is deliberately not these numbers - see the
     * note in evaluateCandidate(). Both are kept so the adjustment is visible
     * rather than hidden inside one figure.
     */
    readonly rawViolations: MetricDelta;
}
/**
 * Replay a candidate against a fixture set.
 *
 * Runs every case twice — once without the candidate and once with it — so the
 * deltas are measured on the same cases in the same session rather than against
 * a remembered baseline. A remembered baseline drifts, and a drifted baseline
 * makes every candidate look like an improvement eventually.
 */
export declare function evaluateCandidate(candidate: LearningCandidate, cases: readonly ReplayCase[], run: CaseRunner, now?: () => string): Promise<ReplayReport>;
/**
 * Whether an evaluation was produced by replaying the fixture set it names.
 *
 * Called before a promotion. An evaluation carrying a digest that does not
 * match the fixtures in front of the reviewer was produced against something
 * else, and "it passed evaluation" then means nothing checkable.
 */
export declare function evaluationMatchesFixtures(evaluation: CandidateEvaluation, cases: readonly ReplayCase[]): boolean;
/**
 * One line a reviewer reads before deciding.
 *
 * Leads with the safety regression when there is one, because that is the only
 * axis where the rest of the sentence stops mattering.
 */
export declare function describeEvaluation(report: ReplayReport): string;
//# sourceMappingURL=replay.d.ts.map