/**
 * `taste.md` and the other Markdown projections.
 *
 * ADR-007: this is a *view*, not a database and not a prompt. It exists so a
 * person can read what the agent has concluded about working with them, in one
 * place, without a UI — and correct it.
 *
 * Two properties make that safe. It is deterministic, so the same ledger always
 * renders the same file and a diff means something actually changed. And it is
 * rebuilt rather than edited, so it cannot drift from the ledger and cannot
 * become a second place where memory lives.
 *
 * Every entry shows its origin, scope, confidence and status. A file that
 * showed only the content would let an inference the agent made and a
 * statement the person made look identical, which is precisely the confusion
 * that makes personalization feel arbitrary.
 *
 * @module @watchskill/dsh-memory/projector
 */
import type { MemoryRecord } from './records.js';
/**
 * Render `taste.md` from the current records.
 *
 * Explicit and inferred preferences are kept in separate sections rather than
 * merged and annotated. Mixing them and relying on a per-line label means the
 * distinction survives only as long as everyone reads carefully, and the whole
 * point is that someone skimming can see which is which.
 */
export declare function renderTaste(records: readonly MemoryRecord[]): string;
/**
 * Render `index.md`: what is remembered, by kind.
 *
 * A map rather than a listing. Somebody arriving at a memory directory needs to
 * know what is in it before they need the contents.
 */
export declare function renderIndex(records: readonly MemoryRecord[]): string;
/**
 * Render `log.md`: the chronology.
 *
 * The ledger is the authority but it is not readable. This is the part a
 * person actually checks when they want to know when the agent started
 * behaving a certain way.
 */
export declare function renderLog(events: readonly {
    readonly at: string;
    readonly kind: string;
    readonly memoryId: string;
    readonly actor: string;
}[], limit?: number): string;
//# sourceMappingURL=projector.d.ts.map