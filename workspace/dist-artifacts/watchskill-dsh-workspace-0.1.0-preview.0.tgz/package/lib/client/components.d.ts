/**
 * The workspace shell, as components.
 *
 * Kept apart from `index.tsx` — which does the slot registration — so that
 * every one of these renders from props alone. That is not tidiness: it is
 * what makes them testable without a browser. `tests/workspace.test.mjs`
 * renders them with `react-dom/server` and asserts on the markup, which is the
 * only gate that catches a degraded mode being drawn as if it worked.
 *
 * Two rendering rules run through all of it.
 *
 * Colour is never the only signal. Every verdict, availability state and gap
 * carries a glyph and a word as well as a tone, because a timeline read on a
 * monochrome screen, at 200% zoom, or by someone who does not distinguish red
 * from green has to say the same thing.
 *
 * Tones come from the brand package's semantic tokens. No hex value appears
 * below. A colour written out here is a colour that gets written out slightly
 * differently in the next panel, and then a theme change misses one of them.
 *
 * @module @watchskill/dsh-workspace/components
 */
import type { ReactNode } from 'react';
import { type ModeState, type WorkspaceMode } from '../modes.js';
import { type InspectorPanel, type SessionHeaderState, type SidebarRow } from '../shell.js';
import { type Timeline, type TimelineDensity, type TimelineEntry } from '../timeline.js';
import { type ComposerConfig, type ComposerRefusal } from '../composer.js';
/** A status badge: glyph, word, tone. Never tone alone. */
export declare function StatusBadge({ status, label }: {
    readonly status: string;
    readonly label?: string;
}): ReactNode;
/** Props for {@link Isolated}. */
export interface IsolatedProps {
    /** What kind of thing this is: `path`, `url`, `identifier`, `timestamp`… */
    readonly kind: string;
    readonly children: ReactNode;
}
/**
 * A span that keeps its own direction inside a paragraph that has another.
 *
 * `needsDirectionIsolation` has existed in the contracts since the i18n work
 * and nothing rendered it, which meant the rule was documented and not
 * enforced. This is the enforcement.
 *
 * The failure it prevents is specific and easy to miss if you do not read the
 * language in question: inside an Arabic sentence, an unisolated `12:30` is
 * reordered by the bidi algorithm into `30:12`, and an unisolated path has its
 * segments reversed. Both look like plausible values. Neither is the value.
 */
export declare function Isolated({ kind, children }: IsolatedProps): ReactNode;
/** Props for {@link ModeSwitcher}. */
export interface ModeSwitcherProps {
    readonly active: WorkspaceMode;
    readonly states: readonly ModeState[];
    readonly onSelect: (mode: WorkspaceMode) => void;
}
/**
 * The mode tabs.
 *
 * An unavailable mode is still rendered and still focusable. It is disabled
 * for activation, carries `aria-disabled` and its reason as the accessible
 * description, and says the reason on the tab. Hiding it would remove the only
 * place a person could learn why the product they were promised is not there.
 */
export declare function ModeSwitcher({ active, states, onSelect }: ModeSwitcherProps): ReactNode;
/** Props for {@link Sidebar}. */
export interface SidebarProps {
    readonly rows: readonly SidebarRow[];
    readonly activeRow: string | null;
    readonly onSelect: (row: SidebarRow) => void;
}
/** The global sidebar, Watch rows and DSH's own operations rows together. */
export declare function Sidebar({ rows, activeRow, onSelect }: SidebarProps): ReactNode;
/** Props for {@link SessionHeaderBar}. */
export interface SessionHeaderProps {
    readonly state: SessionHeaderState;
}
/**
 * The session header.
 *
 * Execution state and verification state are two separate chips with two
 * separate labels, and neither is ever rendered in the other's tone. That is
 * the whole point of the row: "the agent finished" and "the world changed"
 * must not be able to look like one fact.
 */
export declare function SessionHeaderBar({ state }: SessionHeaderProps): ReactNode;
/** Props for {@link InspectorTabs}. */
export interface InspectorTabsProps {
    readonly active: InspectorPanel;
    readonly onSelect: (panel: InspectorPanel) => void;
    /** Rendered body for the active panel; the shell supplies it. */
    readonly children?: ReactNode;
}
/** The right inspector's tab strip and panel region. */
export declare function InspectorTabs({ active, onSelect, children }: InspectorTabsProps): ReactNode;
/** Props for {@link SensoryTimelineStrip}. */
export interface SensoryTimelineProps {
    readonly timeline: Timeline;
    readonly onDensity: (density: TimelineDensity) => void;
    readonly onSelect: (entry: TimelineEntry) => void;
}
/**
 * The bottom timeline.
 *
 * The accessible alternative is not an afterthought here — the whole thing is
 * a list of lanes, each a list of entries, each a button with a text label.
 * The visual layout is applied over that, rather than the text being generated
 * from a canvas after the fact.
 */
export declare function SensoryTimelineStrip({ timeline, onDensity, onSelect }: SensoryTimelineProps): ReactNode;
/** Props for {@link ComposerPanel}. */
export interface ComposerPanelProps {
    readonly config: ComposerConfig;
    /** Refusals from the last agent proposal, when there were any. */
    readonly refusals?: readonly ComposerRefusal[];
}
/**
 * The composer summary and its refusals.
 *
 * A refused agent proposal is *shown*, not swallowed. If the agent asked for
 * the camera and did not get it, the person needs to know that is why the
 * answer is thin — and the refusal is also the fastest path to granting it
 * deliberately.
 */
export declare function ComposerPanel({ config, refusals }: ComposerPanelProps): ReactNode;
/** Props for {@link WorkspaceShell}. */
export interface WorkspaceShellProps {
    readonly sessionId: string;
    readonly mode: WorkspaceMode;
    readonly modeStates: readonly ModeState[];
    readonly header: SessionHeaderState;
    readonly rows: readonly SidebarRow[];
    readonly panel: InspectorPanel;
    readonly timeline: Timeline;
    readonly composer: ComposerConfig;
    readonly onMode: (mode: WorkspaceMode) => void;
    readonly onPanel: (panel: InspectorPanel) => void;
    readonly onDensity: (density: TimelineDensity) => void;
    readonly onEntry: (entry: TimelineEntry) => void;
    readonly onRow: (row: SidebarRow) => void;
    /** The active mode's own surface. */
    readonly children?: ReactNode;
}
/**
 * The whole product, composed.
 *
 * One `data-watch-session` attribute at the root, carrying the session id, and
 * every region inside it. That attribute is not decoration: the test asserts
 * there is exactly one of it, which is the cheapest possible statement of the
 * invariant that the seven modes share one session.
 */
export declare function WorkspaceShell(props: WorkspaceShellProps): ReactNode;
//# sourceMappingURL=components.d.ts.map