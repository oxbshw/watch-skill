/**
 * The workspace shell, registered into DeepSeek Harness's own slots.
 *
 * Nothing is patched and nothing is replaced. The shell occupies generic slots
 * upstream already declares — which is what keeps the Agent mode *being* DSH's
 * conversation rather than a reimplementation of it that drifts.
 *
 * @module @watchskill/dsh-workspace/client
 */
import type { Context } from '@deepseek-ai/cordis';
import { StatusBadge, WorkspaceShell } from './components.js';
export * from './components.js';
export * from '../modes.js';
export * from '../shell.js';
export * from '../timeline.js';
export * from '../composer.js';
/** Services this half needs before it can register anything. */
export declare const inject: string[];
/**
 * Register the shell's regions.
 *
 * Each region goes into the slot upstream provides for it, at an order that
 * leaves room above and below for other plugins. A distribution that took
 * order 0 everywhere would be a distribution no third-party capability could
 * sit alongside, which is the opposite of what the ecosystem path needs.
 */
export declare function apply(ctx: Context): void;
export { StatusBadge, WorkspaceShell };
//# sourceMappingURL=index.d.ts.map