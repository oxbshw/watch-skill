/**
 * The sensory timeline: one more projection, never a second record.
 *
 * The bottom of the workspace shows what was seen, heard, read, done and
 * decided, laid out on one clock. It is tempting to build that as its own
 * store — capture events as they stream, keep them in a ring buffer, render
 * from there. That is exactly the mistake this module refuses to make. A
 * second store means two answers to "what happened", and the moment they
 * disagree the receipt stops being worth anything.
 *
 * So the timeline is a pure fold over state that already exists: DSH's session
 * events and the Watch projection built from them, plus resolved evidence when
 * the caller has it. Nothing here reads a clock, fetches anything, or invents
 * an entry. Two things follow, and both are tested:
 *
 * - **A gap stays a gap.** Evidence that reports missing capture produces a
 *   `gap` entry with its own range. It is never interpolated, never smoothed,
 *   and never omitted because it looks untidy next to entries around it.
 * - **Density hides, it does not decide.** `collapsed` shows less than
 *   `analysis`, but verdicts, actions and errors survive every density. A
 *   timeline that could hide a FAILED at low density would be a timeline whose
 *   default setting makes the product look better than it is.
 *
 * Memory events are deliberately absent. The timeline is *sensory*: it answers
 * what was perceived. What the agent remembered is a Trajectory row and a
 * Memory surface, and putting it in a perception lane would blur the one
 * distinction ADR-006 exists to keep.
 *
 * @module @watchskill/dsh-workspace/timeline
 */
import type { EvidenceRecord, TemporalRange, Verdict } from '@watchskill/dsh-contracts';
import type { SessionEventLike, WatchProjection } from '@watchskill/dsh-trajectory';
/** The lanes the timeline lays out, top to bottom. */
export type TimelineLane = 'media' | 'speech' | 'ocr' | 'actions' | 'tools' | 'network' | 'errors' | 'verdicts';
/** Every lane, in presentation order. */
export declare const TIMELINE_LANES: readonly TimelineLane[];
/** How much of the timeline is on screen. */
export type TimelineDensity = 'collapsed' | 'compact' | 'analysis';
/**
 * Which lanes each density renders.
 *
 * The three sets are nested on purpose — increasing density only ever adds. A
 * density that swapped one lane for another would make "I did not see it"
 * depend on a setting rather than on the record.
 */
export declare const DENSITY_LANES: Readonly<Record<TimelineDensity, readonly TimelineLane[]>>;
/**
 * Lanes that no density may hide.
 *
 * Stated separately from the table above so the invariant is checkable
 * directly rather than inferred from three lists staying in sync.
 */
export declare const ALWAYS_VISIBLE_LANES: readonly TimelineLane[];
/** What kind of thing an entry is, which decides how it draws. */
export type TimelineKind = 'point' | 'span' | 'gap';
/** One thing that happened, on one lane. */
export interface TimelineEntry {
    /** Stable across rebuilds of the same input; what a deep link points at. */
    readonly entryId: string;
    readonly lane: TimelineLane;
    readonly kind: TimelineKind;
    /** DSH log sequence. The only ordering authority — never wall clock. */
    readonly seq: number;
    /** Wall clock, epoch milliseconds, for the header ruler. */
    readonly time: number;
    /** Position on the source's own clock, when the entry has one. */
    readonly range: TemporalRange | null;
    /** One line. Presentation only; nothing resolves from it. */
    readonly label: string;
    /** The Trajectory record this came from, when it came from one. */
    readonly recordId: string | null;
    readonly evidenceId: string | null;
    readonly verdict: Verdict | null;
    /**
     * Where the lane assignment came from.
     *
     * `evidence` means a resolved EvidenceRecord's modality decided it.
     * `record` means only the record type was known. The field exists so the UI
     * can avoid implying a precision it does not have, and so a test can assert
     * that an unresolved evidence record is never filed under a sensory lane it
     * was merely assumed to belong to.
     */
    readonly laneSource: 'evidence' | 'record' | 'event';
}
/** A built timeline: entries, and the lanes actually populated. */
export interface Timeline {
    readonly sessionId: string;
    readonly density: TimelineDensity;
    readonly entries: readonly TimelineEntry[];
    /** Lanes with at least one entry, in presentation order. */
    readonly populated: readonly TimelineLane[];
    /**
     * How many entries the density is hiding.
     *
     * Shown in the collapsed control. A timeline that hid things silently would
     * make its own default setting a way to miss something.
     */
    readonly hidden: number;
}
/** What the builder reads. All of it already exists elsewhere. */
export interface TimelineInput {
    readonly sessionId: string;
    /** The same events the projection was folded from. */
    readonly events: readonly SessionEventLike[];
    readonly projection: WatchProjection;
    /** Resolved evidence, when the caller has fetched it. Optional by design. */
    readonly evidence?: ReadonlyMap<string, EvidenceRecord>;
}
/**
 * Build the timeline.
 *
 * Deterministic: the same input produces the same entries in the same order,
 * including entry ids. Ordering is by DSH sequence and then by lane, so two
 * things logged at the same sequence never swap places between renders.
 */
export declare function buildTimeline(input: TimelineInput, density: TimelineDensity): Timeline;
/**
 * Digest of a built timeline.
 *
 * The same input must produce the same timeline, and this is how that is
 * asserted rather than assumed — the same reason `projectionHash` exists next
 * door. Implemented as FNV-1a over the entry identities, which is enough to
 * catch a reordering or a changed field and cheap enough to run in a render.
 */
export declare function timelineDigest(timeline: Timeline): string;
/**
 * Whether a timeline contains a gap the density is hiding.
 *
 * Used by the collapsed control to say "3 hidden, including a capture gap"
 * rather than "3 hidden". The count alone is not enough: a hidden gap is the
 * one thing whose absence changes what the timeline appears to prove.
 */
export declare function hasHiddenGap(input: TimelineInput, density: TimelineDensity): boolean;
//# sourceMappingURL=timeline.d.ts.map