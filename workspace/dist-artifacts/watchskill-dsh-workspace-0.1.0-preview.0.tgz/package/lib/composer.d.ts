/**
 * The composer: what this turn is allowed to see, keep, do and claim.
 *
 * DSH's composer asks one question — what do you want to say. Watch needs
 * seven more, and they are the ones that decide whether an answer is worth
 * anything: which sources are in scope, which senses are on, what may be
 * remembered, what the agent may do, what would count as proof, what it may
 * spend, and what may leave the machine.
 *
 * The configuration itself is the easy half. The load-bearing half is
 * {@link proposeChange}, and the rule it enforces:
 *
 * > The agent may narrow. Only a person may widen.
 *
 * Five axes are one-way for the agent — source scope, cloud media, egress,
 * side effects, and assurance. Every one of them has the same failure shape:
 * the agent hits a wall, reasons its way to "I'll just enable the thing that
 * would let me finish", and the guarantee the person thought they had is gone
 * without a dialog ever appearing. Making the widening *unrepresentable* from
 * the agent's side is the only version of this that holds, because any version
 * that depends on the model choosing correctly is a version that fails on the
 * day the model is convinced by something it read on a page.
 *
 * Narrowing is deliberately free. An agent that decides it does not need the
 * camera should not need permission to stop using it.
 *
 * @module @watchskill/dsh-workspace/composer
 */
/** Where observation comes from. */
export type SourceKind = 'video' | 'live' | 'browser' | 'screen' | 'window' | 'camera' | 'microphone' | 'files';
/** Every source kind, for enumerating the section. */
export declare const SOURCE_KINDS: readonly SourceKind[];
/** How much of the selected sources is in play. */
export type ScopeKind = 'all' | 'source' | 'time_range' | 'region' | 'selected_evidence';
/** Which senses are on. */
export type ObserveChannel = 'visual' | 'ocr' | 'speech' | 'speaker' | 'audio_events' | 'dom' | 'network';
/** Every observation channel. */
export declare const OBSERVE_CHANNELS: readonly ObserveChannel[];
/** What may be remembered from this turn (ADR-006 scopes). */
export type RememberMode = 'off' | 'session' | 'personal' | 'workspace' | 'explicit';
/** How far a side effect may go. */
export type SideEffectPolicy = 'none' | 'reversible_only' | 'approved_each' | 'permitted_set';
/**
 * How strong a claim this turn is allowed to make.
 *
 * `deterministic` means an executable expectation against world evidence.
 * `observed` means someone looked. `none` means no verification is attempted
 * and nothing may be reported as proven.
 */
export type Assurance = 'none' | 'observed' | 'deterministic';
/** Where media and text are permitted to go. */
export interface PrivacySection {
    /** No non-loopback egress from any role. */
    readonly offlineOnly: boolean;
    /** Media never leaves the machine, even when text may. */
    readonly localMediaOnly: boolean;
    /**
     * Explicit destinations egress is permitted to.
     *
     * An allowlist rather than a boolean: "cloud is on" is not a permission, it
     * is a category. The set is what a receipt can name.
     */
    readonly egressRoutes: readonly string[];
}
/** What this turn may spend. */
export interface BudgetSection {
    readonly latencyMs: number | null;
    readonly maxTokens: number | null;
    readonly maxCostUsd: number | null;
    readonly gpuSeconds: number | null;
    /** Retention class for artifacts this turn captures. */
    readonly retentionClass: string;
}
/** What would count as proof. */
export interface VerifySection {
    /** Plain-language statement of what should be true afterwards. */
    readonly expectation: string;
    /** Contract id, when a reusable one was chosen. */
    readonly contractId: string | null;
    readonly assurance: Assurance;
    readonly timeoutMs: number | null;
}
/** The whole composer state. */
export interface ComposerConfig {
    readonly sources: readonly SourceKind[];
    readonly scope: ScopeKind;
    /** Ids the scope refers to, when it refers to specific things. */
    readonly scopeRefs: readonly string[];
    readonly observe: readonly ObserveChannel[];
    readonly remember: RememberMode;
    /** Memory ids the person explicitly selected, when remember is `explicit`. */
    readonly rememberRefs: readonly string[];
    readonly permittedTools: readonly string[];
    readonly sideEffects: SideEffectPolicy;
    readonly verify: VerifySection;
    readonly budget: BudgetSection;
    readonly privacy: PrivacySection;
}
/**
 * The default a new session opens on.
 *
 * Deliberately narrow. A default that had the camera on, cloud egress open and
 * side effects permitted would be a product that assumed consent it never
 * asked for, and every one of those settings is easier to turn on than to
 * discover was on.
 */
export declare function defaultComposer(): ComposerConfig;
/** Who is asking for a change. */
export type Actor = 'user' | 'agent';
/** A partial change to the composer. */
export type ComposerChange = {
    readonly [K in keyof ComposerConfig]?: ComposerConfig[K];
};
/** The five axes the agent may not widen. */
export type GuardedAxis = 'source_scope' | 'cloud_media' | 'egress' | 'side_effects' | 'assurance';
/** Every guarded axis, for enumerating the refusals a UI must explain. */
export declare const GUARDED_AXES: readonly GuardedAxis[];
/** One reason a change was refused. */
export interface ComposerRefusal {
    readonly axis: GuardedAxis;
    readonly message: string;
    /** What the person would have to do. Never a bare "not permitted". */
    readonly fix: string;
}
/** The outcome of proposing a change. */
export type ComposerDecision = {
    readonly ok: true;
    readonly config: ComposerConfig;
    readonly changed: readonly string[];
} | {
    readonly ok: false;
    readonly config: ComposerConfig;
    readonly refusals: readonly ComposerRefusal[];
};
/**
 * Apply a proposed change, or refuse it with reasons.
 *
 * A user proposal is applied. An agent proposal is checked against all five
 * guarded axes and refused *in full* if any of them widens — never partially
 * applied. Partial application would let an agent widen one axis per turn and
 * arrive at the same place in five turns, which is the same failure with more
 * steps.
 */
export declare function proposeChange(current: ComposerConfig, change: ComposerChange, actor: Actor): ComposerDecision;
/**
 * Whether a configuration can be submitted, and what is missing if not.
 *
 * The one hard requirement is the honest one: a turn that asks for a
 * deterministic verdict has to say what it expects. "Verify that it worked" is
 * not an expectation, and a contract with no statement in it can only ever
 * return UNVERIFIED — better to say so before the run than after it.
 */
export declare function validate(config: ComposerConfig): readonly string[];
/**
 * One line summarizing what the composer is set to.
 *
 * Rendered above the input, where it is read by people who will not open the
 * panel. It leads with the two things that decide whether an answer means
 * anything — what is being observed and what would count as proof.
 */
export declare function describeComposer(config: ComposerConfig): string;
//# sourceMappingURL=composer.d.ts.map