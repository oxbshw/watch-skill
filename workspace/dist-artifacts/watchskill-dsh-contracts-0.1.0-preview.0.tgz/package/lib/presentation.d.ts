/**
 * Rules about how results may be presented.
 *
 * These live in the contracts package rather than in a component because they
 * are product rules, not styling choices. "Green belongs to VERIFIED alone" is
 * the same commitment whether it is rendered by a React card, a terminal
 * summary or a CI annotation, and keeping it here means there is one place to
 * change it and one place to test it.
 *
 * Everything below is a pure function over data that already crossed the wire.
 * No DOM, no React, no Node.
 *
 * @module @watchskill/dsh-contracts/presentation
 */
import type { Freshness, Verdict } from './index.js';
/** How a result is allowed to be presented. */
export type ResultTone = 'success' | 'error' | 'caution';
/**
 * The tone one verdict is rendered in.
 *
 * `INCONCLUSIVE`, `STALE`, `BLOCKED` and `UNVERIFIED` share the caution tone
 * on purpose. They are not failures, and styling them as errors teaches people
 * to dismiss them — which is how an unproven result comes to be accepted as a
 * proven one. They are also not successes, which is the more obvious half.
 */
export declare function verdictTone(verdict: Verdict): ResultTone;
/** How a freshness state should be labelled, or null when it needs no label. */
export declare function freshnessLabel(freshness: Freshness): string | null;
/** One check inside a verification contract, as a result carries it. */
export interface PresentableCheck {
    readonly checkId: string;
    readonly kind: string;
    readonly description: string | null;
    /**
     * Tri-state on purpose. A check that could not run is not a check that
     * failed, and flattening the two turns "we did not look" into "it is broken"
     * — or, worse, the reverse.
     */
    readonly passed: boolean | null;
    readonly detail: string | null;
}
/** A verification result, ready to render. */
export interface PresentableVerdict {
    readonly verdict: Verdict;
    readonly reason: string;
    readonly checks: readonly PresentableCheck[];
    readonly contractDigest: string;
    readonly assurance: string | null;
}
/**
 * Parse a tool result into a verdict.
 *
 * Returns null rather than guessing. A result this cannot read renders as a
 * generic row, which is honest; inventing a verdict to fill a card would not
 * be.
 */
export declare function parseVerdict(value: unknown): PresentableVerdict | null;
/** One cited moment, ready to render. */
export interface PresentableCitation {
    readonly evidenceId: string;
    readonly text: string;
    /** Milliseconds into the source, or null for a citation with no timing. */
    readonly atMs: number | null;
    readonly modality: string;
    readonly provenance: string;
    readonly freshness: Freshness;
}
/** An evidence-linked answer, ready to render. */
export interface PresentableAnswer {
    readonly answer: string;
    readonly citations: readonly PresentableCitation[];
    /** The engine's own assessment of whether it had enough to answer. */
    readonly groundedness: 'sufficient' | 'insufficient' | null;
}
/**
 * Parse a source-query result into an answer.
 *
 * Returns null for a refusal or an unreadable payload, so a failure never
 * renders as a grounded answer with nothing behind it.
 */
export declare function parseAnswer(value: unknown): PresentableAnswer | null;
/**
 * Format a media position the way a person reads one.
 *
 * @returns `m:ss` under an hour, `h:mm:ss` above it, or null when there is no
 * usable timestamp — which a caller renders as no timestamp rather than as
 * `0:00`, because those mean different things.
 */
export declare function formatTimestamp(atMs: number | null): string | null;
//# sourceMappingURL=presentation.d.ts.map