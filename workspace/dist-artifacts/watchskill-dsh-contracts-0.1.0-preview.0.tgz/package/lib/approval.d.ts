/**
 * An approval covers one action, and only the action it was shown.
 *
 * The failure this module exists to prevent is subtle and completely silent
 * when it happens. A person is shown "click Confirm on the payment page" and
 * approves it. Between the approval and the dispatch, something changes the
 * action — a different target, a different page, an extra field — and the
 * approval, which was for a description rather than for a value, still
 * applies. The receipt then records a properly approved action nobody agreed
 * to, and it looks correct in every audit.
 *
 * So an approval binds to a digest of the exact action, and
 * {@link checkApproval} refuses when the action's digest is not the one that
 * was approved. Not warns, not re-prompts silently — refuses, and says which
 * field moved, because "your approval no longer matches" is a sentence a
 * person can act on and "permission denied" is not.
 *
 * Three other properties come along with it, and each closes a way an approval
 * gets stretched past what it covered:
 *
 * - **It expires.** An approval held open across a long session is an approval
 *   whose context the person no longer remembers.
 * - **It is single-use by default.** A "yes" to one click is not a yes to
 *   every click of that shape.
 * - **It names who gave it.** An approval with no subject cannot be audited,
 *   and an unauditable approval is indistinguishable from an assumed one.
 *
 * @module @watchskill/dsh-contracts/approval
 */
/** What the person actually agreed to. */
export interface Approval {
    readonly approvalId: string;
    /**
     * Digest of the exact action that was shown.
     *
     * The load-bearing field. Everything else is metadata about the agreement;
     * this is the agreement.
     */
    readonly inputDigest: string;
    /** A short description of what was shown, for the audit trail and the UI. */
    readonly summary: string;
    readonly grantedByUserId: string;
    readonly grantedAtMs: number;
    readonly expiresAtMs: number;
    /**
     * How many times it may be used.
     *
     * One, unless somebody deliberately granted more. A standing approval is a
     * real thing people sometimes want and never the default.
     */
    readonly maxUses: number;
    readonly uses: number;
    /** Set when the approval was withdrawn before it was used. */
    readonly revokedAtMs: number | null;
}
/** An action asking to be dispatched. */
export interface PendingAction {
    readonly operationId: string;
    readonly inputDigest: string;
    readonly summary: string;
    /** Whether this could change something outside Watch. */
    readonly consequential: boolean;
}
/** Why an approval did not cover an action. */
export type ApprovalRefusalCode = 'no_approval' | 'digest_mismatch' | 'expired' | 'revoked' | 'exhausted' | 'wrong_person';
/** The outcome of checking an approval against an action. */
export type ApprovalDecision = {
    readonly ok: true;
    readonly approval: Approval;
} | {
    readonly ok: false;
    readonly code: ApprovalRefusalCode;
    readonly message: string;
    readonly fix: string;
};
/**
 * Whether an approval covers an action.
 *
 * The digest comparison is first and is the whole point. Note that it happens
 * before the expiry check: an action that does not match should say so rather
 * than say "expired", because those two suggest completely different next
 * steps, and telling somebody to approve again when the action changed
 * underneath them is how the change gets approved.
 */
export declare function checkApproval(approval: Approval | null, action: PendingAction, context: {
    readonly nowMs: number;
    readonly actorUserId: string;
}): ApprovalDecision;
/** Record that an approval was spent. */
export declare function consume(approval: Approval): Approval;
/** Withdraw an approval before it is used. */
export declare function revoke(approval: Approval, atMs: number): Approval;
/**
 * How long an approval lasts by default.
 *
 * Two minutes: long enough for a page to load and an action to dispatch, short
 * enough that it cannot survive somebody walking away from the machine.
 */
export declare const DEFAULT_APPROVAL_TTL_MS = 120000;
/**
 * Grant an approval for exactly one action.
 *
 * Takes the action rather than a description, so an approval cannot be minted
 * for something vaguer than what will be dispatched — which is the other half
 * of the digest rule, and the half that is easy to leave out.
 */
export declare function grantFor(action: PendingAction, context: {
    readonly approvalId: string;
    readonly grantedByUserId: string;
    readonly nowMs: number;
    readonly ttlMs?: number;
    readonly maxUses?: number;
}): Approval;
//# sourceMappingURL=approval.d.ts.map