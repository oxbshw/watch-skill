/**
 * Language-aware evidence.
 *
 * The correction this module encodes (spec §37): Watch is not an English
 * product with translations bolted on, and it is not an Arabic one either. It
 * is language-independent architecture with a *measured* support matrix — and
 * the two claims are very different. "Handles Unicode" is architecture.
 * "Reads Thai subtitles well" is a measurement, and it belongs to a
 * qualification result rather than to a type.
 *
 * Five things are kept separate that products routinely conflate:
 *
 * ```
 * UI locale            what the interface is in
 * source language(s)   what the material is in
 * script(s)            what alphabet it is written in
 * response language    what the agent answers in
 * translation target   an optional derived view
 * ```
 *
 * Changing the interface language must not translate evidence. A source can
 * contain several languages in one frame. And a translation is *derived data
 * with its own provenance* — the original text stays the evidence, because a
 * citation that resolved to a translation would be citing something no one
 * ever said.
 *
 * @module @watchskill/dsh-contracts/language
 */
/**
 * Which way a span reads.
 *
 * Per span, not per page. One frame can hold an Arabic sentence with a Latin
 * product name and a timestamp inside it, and a page-level direction would get
 * two of those three wrong.
 */
export type TextDirection = 'ltr' | 'rtl' | 'mixed' | 'unknown';
/** Unicode script identity, as the OCR and ASR contracts report it. */
export type ScriptTag = 'Latin' | 'Arabic' | 'Hebrew' | 'Cyrillic' | 'Greek' | 'Han' | 'Hiragana' | 'Katakana' | 'Hangul' | 'Devanagari' | 'Thai' | 'Lao' | 'Khmer' | 'Myanmar' | 'Tibetan' | 'Unknown';
/**
 * Detect the scripts present in a string.
 *
 * Range-based rather than library-based on purpose: this runs on the browser
 * side of an evidence panel, and pulling a full ICU table into a bundle to
 * answer "is there Arabic in here" is not a trade worth making. It is
 * deliberately coarse — it reports which scripts appear, which is what
 * direction and routing need, not a language identification.
 */
export declare function detectScripts(text: string): readonly ScriptTag[];
/**
 * Which way a string reads.
 *
 * `mixed` is a real answer, not a failure to decide. A layout that renders
 * mixed content as though it were uniformly one direction produces text that
 * is technically present and unreadable.
 */
export declare function detectDirection(text: string): TextDirection;
/**
 * A translation of an evidence span.
 *
 * Derived data with its own provenance, deliberately shaped so it can never be
 * mistaken for the original: it names the engine that produced it and carries
 * no evidence id of its own.
 */
export interface DerivedTranslation {
    readonly targetLanguage: string;
    readonly text: string;
    readonly engine: string;
    readonly engineVersion: string;
    readonly translatedAt: string;
    /** Null unless the engine produces a calibrated score. */
    readonly confidence: number | null;
}
/**
 * The language-aware text of one piece of evidence.
 *
 * `originalText` is the evidence. Everything else is a view of it.
 */
export interface LanguageAwareText {
    /**
     * Exactly what was observed, byte for byte.
     *
     * The evidence authority. Never normalized in place, never replaced by a
     * translation, and what a citation resolves to.
     */
    readonly originalText: string;
    /**
     * A folded form for retrieval only.
     *
     * Case-folded, diacritic-stripped, width-normalized — whatever the index
     * needs to match a query someone typed differently from how it appears.
     * Never displayed, never cited, and never the thing a verdict is about.
     */
    readonly normalizedText: string | null;
    /** BCP-47 tags where known. Empty rather than guessed. */
    readonly languageTags: readonly string[];
    readonly scripts: readonly ScriptTag[];
    readonly direction: TextDirection;
    /** Null unless the detector is calibrated. */
    readonly languageConfidence: number | null;
    readonly producer: string;
    readonly producerVersion: string;
    /** Derived views. A citation never resolves to one of these. */
    readonly translations: readonly DerivedTranslation[];
    readonly qualityWarnings: readonly string[];
}
/**
 * Normalize text for retrieval.
 *
 * NFKC plus case folding plus combining-mark removal: enough that a query
 * typed without diacritics finds text written with them, and that half-width
 * and full-width forms match. Deliberately not stemming or transliteration —
 * those change what a word means, and an index that matched across them would
 * return hits a person cannot see the reason for.
 */
export declare function normalizeForRetrieval(text: string): string;
/**
 * Build the language-aware text for an observed span.
 *
 * The normalized form is computed here rather than accepted from a caller, so
 * every index in the product folds text the same way. Two normalizers that
 * disagree produce a search that finds a result in one surface and not in
 * another, for reasons nobody can see.
 */
export declare function describeText(originalText: string, producer: string, producerVersion: string, options?: {
    readonly languageTags?: readonly string[];
    readonly languageConfidence?: number | null;
    readonly qualityWarnings?: readonly string[];
}): LanguageAwareText;
/**
 * Attach a translation without disturbing the original.
 *
 * Returns a new value. The original text is unchanged and stays first, because
 * the moment a translation could overwrite it, a citation would resolve to
 * something nobody said.
 */
export declare function withTranslation(text: LanguageAwareText, translation: DerivedTranslation): LanguageAwareText;
/**
 * What a surface should display, given a reader's preference.
 *
 * Returns the original unless a translation for the requested language exists,
 * and always says which it returned. A caller that renders this without
 * showing `isOriginal` is presenting derived text as observed text.
 */
export declare function displayText(text: LanguageAwareText, preferredLanguage: string | null): {
    readonly text: string;
    readonly isOriginal: boolean;
    readonly direction: TextDirection;
};
/**
 * Whether a span must be isolated from the surrounding text direction.
 *
 * Code, URLs, identifiers and timestamps read left to right inside an
 * otherwise right-to-left paragraph, and without isolation the bidi algorithm
 * reorders them into something that looks plausible and is wrong — a path with
 * its segments reversed, a timestamp reading 30:2.
 */
export declare function needsDirectionIsolation(kind: string): boolean;
//# sourceMappingURL=language.d.ts.map