/**
 * `watchCore` — the Host-side Cordis service that owns the Bridge to Watch Core.
 *
 * Everything Watch can perceive, prove or remember reaches DeepSeek Harness
 * through this one service. It owns connection lifecycle, protocol
 * negotiation, capability truth, deadlines, cancellation and correlation; it
 * deliberately owns no domain knowledge, because the Bridge must never become
 * a second store of truth (ADR-004).
 *
 * The failure posture matters as much as the happy path: a Watch Core that
 * will not start leaves the Workspace fully usable with Watch features
 * disabled and a stated fix. It never blocks boot.
 *
 * @module @watchskill/dsh-core-bridge
 */
import { type Context, Service } from '@deepseek-ai/cordis';
import s from '@deepseek-ai/schemastery';
import type { CapabilityTruth, HandshakeResult, WatchCoreHealth, WatchResult } from '@watchskill/dsh-contracts';
export type * from './transport.js';
export { MockTransport } from './transport/mock.js';
export { StdioTransport } from './transport/stdio.js';
/** Deployment configuration for the Bridge. */
export interface Config {
    /**
     * How to reach Watch Core.
     *
     * `auto` (the default) tries the local engine and falls back to the mock
     * backend only when the command is genuinely not installed. That is the
     * difference that makes an automatic default acceptable: a machine without
     * Watch Core gets a working Workspace and an invitation to install it, while
     * a Watch Core that *is* present and fails is reported as a fault rather
     * than hidden behind a mock that answers nothing.
     *
     * `stdio` and `mock` pin the choice for a deployment that has already made
     * it.
     */
    readonly transport: 'auto' | 'stdio' | 'mock';
    /** Executable that starts Watch Core in Bridge mode. */
    readonly command: string;
    readonly args: string[];
    /** Working directory for the child. Empty inherits the Host's. */
    readonly cwd: string;
    readonly startupTimeoutMs: number;
    /** Deadline applied to a request that does not carry its own. */
    readonly requestTimeoutMs: number;
    /** Connect during plugin activation rather than on first use. */
    readonly autoConnect: boolean;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The Bridge to Watch Core: perception, evidence and verification. */
        watchCore: WatchCoreService;
    }
}
/** Options a caller may attach to one Bridge request. */
export interface RequestOptions {
    /** Overrides the configured default deadline. */
    readonly deadlineMs?: number;
    /** Reuses an existing correlation id instead of minting one. */
    readonly correlationId?: string;
    /** Cancels the wait, and asks Core to stop the work. */
    readonly signal?: AbortSignal;
}
/** Extra fields every side-effecting Bridge command must carry (ADR-004). */
export interface SideEffectEnvelope {
    readonly operationId: string;
    readonly idempotencyKey: string;
    readonly inputDigest: string;
    readonly expectedResourceVersion?: string;
    readonly approvalId?: string;
}
/** The Bridge between DeepSeek Harness and Watch Core. */
export declare class WatchCoreService extends Service {
    private readonly config;
    /** Loader validation for the Bridge's deployment-varying values. */
    static Config: s<Config>;
    private transport;
    private state;
    /** In flight so concurrent callers share one attempt instead of racing. */
    private connecting;
    private readonly healthListeners;
    private admitting;
    /**
     * Capabilities withheld because their contract family drifted.
     *
     * Held separately from the handshake so {@link isCapable} can refuse one
     * capability without every caller re-deriving which families it needs.
     */
    private driftAffected;
    constructor(ctx: Context, config: Config);
    /** Current Bridge health. Always safe to read, including before connect. */
    health(): WatchCoreHealth;
    /** Capability truth from the last successful handshake. */
    capabilities(): readonly CapabilityTruth[];
    /**
     * Whether one capability is usable right now.
     *
     * `probed` is deliberately excluded: a reachable endpoint is not a
     * successful request, and a surface that treats it as one will eventually
     * offer a button that fails.
     */
    isCapable(capabilityId: string): boolean;
    /** Subscribe to health changes; returns an unsubscribe function. */
    onHealthChange(listener: (health: WatchCoreHealth) => void): () => void;
    /**
     * Connect and negotiate, or return the outcome of the attempt already
     * running. Repeated calls never spawn a second Core.
     */
    connect(): Promise<WatchResult<HandshakeResult>>;
    /**
     * Issue one read-only Bridge request.
     *
     * A read is idempotent by definition, so this path may be retried by the
     * caller. Side effects must go through {@link command}, which will not let
     * that happen by accident.
     */
    request<T>(method: string, params?: unknown, options?: RequestOptions): Promise<WatchResult<T>>;
    /**
     * Issue one side-effecting Bridge command.
     *
     * The envelope is required rather than optional because the reconnect path
     * needs it: on reconnection Core replays the same receipt for a known
     * `idempotencyKey`, or reports a conflict. A command without one could only
     * be recovered by reissuing it, which is exactly the blind retry the product
     * forbids.
     */
    command<T>(method: string, params: Record<string, unknown>, envelope: SideEffectEnvelope, options?: RequestOptions): Promise<WatchResult<T>>;
    /** Bring the Bridge up, negotiate the protocol, and record the outcome. */
    private runConnect;
    /** Connect on demand for callers that did not wait for auto-connect. */
    private ensureReady;
    /** Build the configured backend. */
    private createTransport;
    /** Apply a health change and notify subscribers exactly once. */
    private publish;
}
export default WatchCoreService;
//# sourceMappingURL=index.d.ts.map