/**
 * In-process Bridge backend used before a real Watch Core is attached.
 *
 * Phase 1 of the plan needs the Host plugin, the profile bundle and the browser
 * half to be installable and demonstrably alive on stock DeepSeek Harness
 * before the Python engine is wired in. This backend is what makes that
 * possible without ever pretending a capability is present.
 *
 * The honesty rules it exists to demonstrate, not to bypass:
 *   - every capability reports `not_tested`, never `machine_tested`;
 *   - it never returns an EvidenceRecord or a verdict, because only Watch Core
 *     may mint those (ADR-002);
 *   - `transport: 'mock'` reaches the UI, so no screen can imply a real engine.
 *
 * @module @watchskill/dsh-core-bridge/transport/mock
 */
import type { WatchResult } from '@watchskill/dsh-contracts';
import type { Transport, TransportEvent, TransportRequest } from '../transport.js';
/** Bridge backend that answers handshake and health, and refuses everything else. */
export declare class MockTransport implements Transport {
    readonly kind: "mock";
    private readonly eventListeners;
    connect(): Promise<WatchResult<void>>;
    send<T>(request: TransportRequest): Promise<WatchResult<T>>;
    subscribe(listener: (event: TransportEvent) => void): () => void;
    onFailure(): () => void;
    dispose(): Promise<void>;
    /** The one answer this backend is entitled to give. */
    private handshake;
}
//# sourceMappingURL=mock.d.ts.map