/**
 * JSON-RPC 2.0 over stdio to a local Watch Core child process.
 *
 * This is the default local transport (ADR-004). stdio was chosen over a
 * loopback port precisely because it has nothing to secure: no port to bind,
 * no CORS to configure, no bootstrap secret to leak between Node and Python.
 * The child's stdin and stdout are the whole attack surface, and they belong
 * to the process that spawned them.
 *
 * Framing is LSP-style `Content-Length` headers rather than newline-delimited
 * JSON: Watch Core streams OCR text and transcripts, which contain newlines,
 * and a length-prefixed frame cannot be split by content.
 *
 * @module @watchskill/dsh-core-bridge/transport/stdio
 */
import type { WatchError, WatchResult } from '@watchskill/dsh-contracts';
import type { Transport, TransportEvent, TransportRequest } from '../transport.js';
/** Everything the transport needs to launch and talk to a Core process. */
export interface StdioTransportOptions {
    readonly command: string;
    readonly args: readonly string[];
    readonly cwd: string | undefined;
    readonly env: Readonly<Record<string, string>> | undefined;
    /** How long the child has to become writable before the connect fails. */
    readonly startupTimeoutMs: number;
}
/** Local child-process Bridge backend. */
export declare class StdioTransport implements Transport {
    private readonly options;
    readonly kind: "stdio";
    private child;
    private buffer;
    private nextId;
    private readonly pending;
    private readonly eventListeners;
    private readonly failureListeners;
    private disposed;
    /** Retained so a late exit can explain itself instead of reporting "null". */
    private lastStderr;
    constructor(options: StdioTransportOptions);
    connect(): Promise<WatchResult<void>>;
    send<T>(request: TransportRequest): Promise<WatchResult<T>>;
    subscribe(listener: (event: TransportEvent) => void): () => void;
    onFailure(listener: (error: WatchError) => void): () => void;
    dispose(): Promise<void>;
    /** Send a notification. Failure is not reportable, so it is not pretended to be. */
    private notify;
    /** Accumulate bytes and drain every complete frame they contain. */
    private receive;
    /** Route one decoded frame to its waiting request, or to event subscribers. */
    private dispatch;
    /** Deliver a request's one and only terminal outcome. */
    private settle;
    /** Report a transport-level failure to the service that owns this backend. */
    private fail;
    /** Handle child exit: fail every in-flight request, then report the loss. */
    private handleExit;
    /**
     * Build the connect-time failure result, keeping the spawn detail intact.
     *
     * `notInstalled` travels in the details so the service can offer a fresh
     * machine the mock backend without also hiding a Watch Core that is present
     * and failing.
     */
    private spawnFailure;
}
//# sourceMappingURL=stdio.d.ts.map