/**
 * The Evidence Inspector.
 *
 * Functionality first, deliberately: this is the panel that answers "what
 * exactly is this citation?", and it answers it from the record Watch Core
 * resolved, not from anything on screen. Two rules govern what it may show.
 *
 * **No evidence reconstruction from display text.** The inspector takes an
 * evidence id and asks for the record. It never assembles one from what a
 * message happens to contain — an inspector that could do that would let a
 * page's own text become the evidence for what that page said.
 *
 * **No fabricated verification state.** A record with no associated
 * verification shows that it has none. It never fills the gap with a default,
 * and the only green in this panel comes from a `VERIFIED` verdict that Watch
 * Core issued.
 *
 * The visual design is intentionally minimal — Phase 3 owns that.
 */
import type { ReactNode } from 'react';
import type { WatchSelection } from '@watchskill/dsh-trajectory';
import type { PresentableVerdict } from '@watchskill/dsh-contracts';
/** The evidence record as Watch Core returns it. */
export interface InspectableEvidence {
    readonly evidenceId: string;
    readonly sourceRevisionId: string;
    readonly artifactIds: readonly string[];
    readonly temporalRange: {
        readonly startMs: number;
        readonly endMs: number;
    } | null;
    readonly modality: string;
    readonly provenance: string;
    readonly producer: string;
    readonly producerVersion: string;
    readonly freshness: string;
    readonly contentDigest: string;
    readonly retentionClass: string;
    readonly confidence: number | null;
    readonly text?: string;
}
/** What the inspector is currently able to show. */
export type InspectorState = 
/** Nothing selected. */
{
    readonly status: 'idle';
}
/** Resolving from Watch Core. */
 | {
    readonly status: 'loading';
    readonly evidenceId: string;
}
/** Resolved. */
 | {
    readonly status: 'ready';
    readonly evidence: InspectableEvidence;
    readonly verification: PresentableVerdict | null;
    readonly receiptId: string | null;
}
/** Could not resolve, with the engine's own fix. */
 | {
    readonly status: 'error';
    readonly message: string;
    readonly fix: string;
};
/** Props assembled by whichever surface mounts the inspector. */
export interface EvidenceInspectorProps {
    readonly selection: WatchSelection;
    readonly state: InspectorState;
    /** Copy a link that restores this selection. */
    readonly onCopyLink?: () => void;
}
/** Render the inspector for the current selection. */
export declare function EvidenceInspector({ selection, state, onCopyLink, }: EvidenceInspectorProps): ReactNode;
//# sourceMappingURL=EvidenceInspector.d.ts.map