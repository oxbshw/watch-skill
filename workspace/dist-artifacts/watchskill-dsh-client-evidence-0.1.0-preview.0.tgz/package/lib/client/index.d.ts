/**
 * The Watch browser half.
 *
 * It registers keyed tool views into DeepSeek Harness's own
 * `tool.call.toolview` slot, which means it needs no Host round-trip at all:
 * everything it renders is already in the conversation the workspace streamed.
 * That is what makes this the right first browser surface — it puts the
 * product's central distinction on screen without adding a second source of
 * truth to keep in sync.
 *
 * A key the shipped composition does not claim falls back to the generic tool
 * row, so registering for Watch's own tools is purely additive.
 *
 * @module @watchskill/dsh-client-evidence/client
 */
import type { Context } from '@deepseek-ai/cordis';
export { VerdictRow } from './VerdictRow.js';
export { SourceAnswerRow } from './SourceAnswerRow.js';
export { EvidenceInspector } from './EvidenceInspector.js';
export { CompareView, DivergenceRow } from './CompareView.js';
export type { CompareViewProps, DivergenceRowProps } from './CompareView.js';
export type { EvidenceInspectorProps, InspectableEvidence, InspectorState } from './EvidenceInspector.js';
export { WATCH_TARGET, WatchSelectionStore, WatchViewBuilder, registerWatchTrajectory, watchTrajectoryDefinition, } from '@watchskill/dsh-trajectory';
/** Services this half needs before it can register anything. */
export declare const inject: string[];
/** Register the Watch tool views into the conversation. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map