/**
 * An evidence-linked answer.
 *
 * The card's job is to keep apart two things that look identical in prose: an
 * answer grounded in something the system observed, and an answer that has been
 * proven correct. This one is the first. It shows the citations behind it, and
 * it says — every time, not only when something went wrong — that nothing here
 * has been verified.
 *
 * The parsing and labelling rules live in
 * `@watchskill/dsh-contracts/presentation`; this file renders them.
 */
import type { ReactNode } from 'react';
import type { PresentableAnswer } from '@watchskill/dsh-contracts';
/** Render one evidence-linked answer and the citations behind it. */
export declare function SourceAnswerRow({ payload }: {
    readonly payload: PresentableAnswer;
}): ReactNode;
//# sourceMappingURL=SourceAnswerRow.d.ts.map