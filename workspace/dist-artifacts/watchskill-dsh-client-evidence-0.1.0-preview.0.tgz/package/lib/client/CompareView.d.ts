/**
 * The Compare surface.
 *
 * Two columns and one answer. The answer is at the top, because it is the
 * thing people came for: *where did these first stop agreeing, in a way that
 * mattered?* Everything below it is context for that sentence.
 *
 * The surface never says passed or failed. A difference between two runs is
 * usually the change somebody asked for, and deciding whether it was the one
 * they wanted is a verification contract. So a verdict divergence is drawn in
 * the verdicts' own tones — because the verdicts have tones — and the
 * comparison itself is drawn neutrally, however dramatic the difference.
 *
 * @module @watchskill/dsh-client-evidence/CompareView
 */
import type { ReactNode } from 'react';
import { type Comparison, type Divergence } from '@watchskill/dsh-trajectory';
/** Props for {@link DivergenceRow}. */
export interface DivergenceRowProps {
    readonly divergence: Divergence;
    readonly leading: boolean;
    readonly onOpen: (divergence: Divergence, side: 'left' | 'right') => void;
}
/**
 * One divergence, with a way into each side.
 *
 * Two buttons rather than one. A divergence is a statement about two things,
 * and a single "open" would have to pick a side on the reader's behalf — which
 * is exactly the choice they are trying to make.
 */
export declare function DivergenceRow({ divergence, leading, onOpen }: DivergenceRowProps): ReactNode;
/** Props for {@link CompareView}. */
export interface CompareViewProps {
    readonly comparison: Comparison;
    /** What the two sides are called, for the column headers. */
    readonly leftLabel: string;
    readonly rightLabel: string;
    readonly onOpen: (divergence: Divergence, side: 'left' | 'right') => void;
}
/** The Compare mode body. */
export declare function CompareView({ comparison, leftLabel, rightLabel, onOpen }: CompareViewProps): ReactNode;
//# sourceMappingURL=CompareView.d.ts.map