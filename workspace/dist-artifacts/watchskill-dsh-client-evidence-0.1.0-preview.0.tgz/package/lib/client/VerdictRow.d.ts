/**
 * The verdict card.
 *
 * This is the smallest surface in the product and the one most worth getting
 * right. Every other screen can be rebuilt; a verdict card that renders
 * `UNVERIFIED` in a way a tired person reads as "done" destroys the only claim
 * Watch makes.
 *
 * The rules it obeys are not defined here — they live in
 * `@watchskill/dsh-contracts/presentation`, where they can be tested without a
 * DOM and where there is exactly one place to change them. This file is the
 * rendering, and nothing about the rendering is allowed to widen them.
 */
import type { ReactNode } from 'react';
import type { PresentableVerdict } from '@watchskill/dsh-contracts';
/** Render the verdict of one verification run. */
export declare function VerdictRow({ payload }: {
    readonly payload: PresentableVerdict;
}): ReactNode;
//# sourceMappingURL=VerdictRow.d.ts.map