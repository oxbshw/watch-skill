/**
 * A worked example: the smallest capability that does something real.
 *
 * Shipped as source rather than as documentation, and exercised by the SDK's
 * own tests, so an example that stops compiling is a failing build rather than
 * a page somebody finds out is wrong at the worst moment.
 *
 * It reads a subtitle file and submits what it found. That is deliberately
 * unglamorous — it is the shape of the thing that matters: declare, probe,
 * observe, submit, and never claim.
 *
 * @module @watchskill/dsh-sdk/example
 */
import type { TechnologyDescriptor } from '@watchskill/dsh-technology';
import { type CapabilityDeclaration, type CoreGateway, type SubmissionResult } from './capability.js';
/** The descriptor an example third-party capability supplies. */
export declare const EXAMPLE_DESCRIPTOR: TechnologyDescriptor;
/** The declaration an example third-party capability supplies. */
export declare const EXAMPLE_DECLARATION: CapabilityDeclaration;
/** One cue the example produces. */
export interface Cue {
    readonly startMs: number;
    readonly endMs: number;
    readonly text: string;
}
/**
 * Parse the smallest useful subtitle format.
 *
 * Real enough to be a real example, small enough that the SDK's shape is what
 * the reader is looking at rather than a parser.
 */
export declare function parseCues(source: string): readonly Cue[];
/**
 * Run the example capability over one source.
 *
 * Every cue becomes a candidate observation. None of them carries an evidence
 * id, because the capability has no way to produce one — the host mints them,
 * and the ids in the result came back from Core.
 */
export declare function runExample(gateway: CoreGateway, input: {
    readonly sourceRevisionId: string;
    readonly subtitles: string;
    readonly capturedAt: string;
}): Promise<readonly SubmissionResult[]>;
//# sourceMappingURL=example.d.ts.map