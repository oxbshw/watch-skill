/**
 * Watch records registered into DeepSeek Harness's own event system.
 *
 * This is the seam the plan insists on. Watch does **not** build a second
 * tracker: it registers a `ConversationNodeDefinition` into
 * `ctx.conversationEvents` — the same registry Trajectory itself uses — and a
 * view target into `ctx.conversationViews`. Both read the single session event
 * log DSH already owns.
 *
 * What that buys is not tidiness. It means a Watch record and the Tool record
 * it came from cannot disagree about when something happened, because they are
 * two projections of the same event at the same sequence number. A separate
 * Watch ledger would eventually drift, and the drift would be invisible.
 *
 * The Trajectory *contribution* union is closed in upstream's own package, so
 * Watch rows cannot be injected into the existing Trajectory ledger without an
 * upstream patch. Rather than take one, Watch registers its own view target
 * over the same events — the arrangement upstream already uses for `chat` and
 * `trajectory`, and additive by construction.
 *
 * @module @watchskill/dsh-trajectory/definition
 */
import type { WatchProjection } from './projection.js';
import type { WatchTrajectoryRecord } from './events.js';
/**
 * The two DSH registries this module needs.
 *
 * Structural rather than imported from Cordis: these are two method
 * signatures, and taking a framework dependency for them would tie a pure
 * module to a runtime it never uses. The browser half passes its real context.
 */
export interface WatchRegistries {
    readonly conversationEvents: {
        register(definition: unknown): void;
    };
    readonly conversationViews: {
        register(definition: unknown): void;
    };
}
/** The view target Watch publishes. Distinct from `trajectory` and `chat`. */
export declare const WATCH_TARGET = "watchEvidence";
/**
 * The Watch event Definition.
 *
 * Typed structurally rather than against upstream's exported generics: this
 * package must build outside the DSH monorepo, where those types are reachable
 * only through the packages the browser bundle is allowed to import. The shape
 * is checked against the real contract by the round-trip tests, which run the
 * same extraction over real event shapes.
 */
export declare function watchTrajectoryDefinition(sessionId: string): unknown;
/** The node shape the view builder folds. */
interface WatchViewNode {
    readonly key: string;
    readonly anchorSeq: number;
    readonly data: {
        readonly records: readonly WatchTrajectoryRecord[];
    };
}
/**
 * The Watch view target's incremental builder.
 *
 * Rebuilds the whole projection on change rather than patching it. The record
 * set for one session is small — tens of rows, not thousands — and a full fold
 * is the same code path replay uses, so the live view and a reopened one
 * cannot diverge. Patching would be faster and would introduce exactly the
 * class of bug this whole design exists to rule out.
 */
declare class WatchViewBuilder {
    private readonly sessionId;
    readonly empty: WatchProjection;
    private nodes;
    constructor(sessionId: string);
    replace(input: {
        nodes: readonly WatchViewNode[];
    }): WatchProjection;
    patch(input: {
        nodes: readonly WatchViewNode[];
    }): WatchProjection;
    private build;
}
/**
 * Register the Watch definition and view target.
 *
 * Both registrations ride Cordis effects, so unloading the plugin removes them
 * and the workspace returns to stock DSH with no Watch rows and no leftover
 * target — which is the uninstall path the bundle promises.
 */
export declare function registerWatchTrajectory(ctx: WatchRegistries, sessionId: string): void;
export { WatchViewBuilder };
//# sourceMappingURL=definition.d.ts.map