/**
 * The Unified Selection Model, and the deep links that serialize it.
 *
 * One canonical selection, not one per panel. That is the whole design: a
 * citation in an answer, a row in Trajectory, a position in a player and the
 * Evidence Inspector are four *projections* of the same value, so selecting in
 * any of them moves all of them, and there is no state to reconcile between
 * them because there is only one.
 *
 * DSH's own Trajectory selection is documented as local to Trajectory, with no
 * anchor deep links. This is the smallest additive Watch-owned extension
 * around it: Watch holds the canonical selection for Watch-related records and
 * drives Trajectory's local selection from it, rather than replacing anything
 * upstream owns.
 *
 * Everything here is pure. A selection is a value, not a store.
 *
 * @module @watchskill/dsh-trajectory/selection
 */
import type { WatchTrajectoryRecord } from './events.js';
/** Which inspector panel a selection opens. */
export type InspectorTab = 'evidence' | 'verification' | 'receipt' | 'memory' | 'source';
/**
 * The one selection every Watch surface responds to.
 *
 * Identifiers only. A selection that carried evidence *content* would be a
 * second copy of it, and the copy in a URL would be one nobody could
 * invalidate.
 */
export interface WatchSelection {
    readonly workspaceId: string;
    readonly sessionId: string;
    /** The Trajectory record, when the selection came from or points at one. */
    readonly recordId: string | null;
    readonly evidenceId: string | null;
    readonly sourceId: string | null;
    readonly sourceRevisionId: string | null;
    readonly verificationId: string | null;
    readonly receiptId: string | null;
    readonly memoryId: string | null;
    /** Where in the source, in milliseconds. */
    readonly atMs: number | null;
    readonly endMs: number | null;
    readonly inspectorTab: InspectorTab | null;
    /** Which surface initiated it, so a surface can skip echoing itself. */
    readonly origin: string;
}
/** A selection with nothing selected, for a fresh session. */
export declare function emptySelection(workspaceId: string, sessionId: string): WatchSelection;
/**
 * Which inspector panel a record should open.
 *
 * Derived rather than stored, so a record selected from Trajectory and the
 * same record reached from a citation land on the same panel.
 */
export declare function tabForRecord(record: WatchTrajectoryRecord): InspectorTab;
/**
 * Select one Trajectory record.
 *
 * This is the reverse direction of the round trip: a Watch row in Trajectory
 * resolves to the same evidence, timestamp and receipt a citation would.
 */
export declare function selectRecord(base: WatchSelection, record: WatchTrajectoryRecord, origin?: string): WatchSelection;
/** One citation as an answer carries it. */
export interface CitationRef {
    readonly evidenceId: string;
    readonly sourceRevisionId: string | null;
    readonly atMs: number | null;
    readonly endMs?: number | null;
}
/**
 * Select a citation from an agent answer.
 *
 * The forward direction: clicking a timestamp in an answer resolves the exact
 * source revision and moment, and finds the Trajectory record that produced
 * it. `records` is searched rather than trusted from the citation, because the
 * record is the thing Trajectory can highlight and the citation only knows its
 * own evidence id.
 */
export declare function selectCitation(base: WatchSelection, citation: CitationRef, records: readonly WatchTrajectoryRecord[], origin?: string): WatchSelection;
/** Whether two selections point at the same thing, ignoring which surface moved. */
export declare function sameSelection(left: WatchSelection, right: WatchSelection): boolean;
/**
 * Serialize a selection as a deep link fragment.
 *
 * A fragment rather than a query string, and identifiers rather than content.
 * A fragment is not sent to a server, which matters because these ids point at
 * someone's private session; and a link that carried evidence *text* would be
 * a copy nobody could invalidate when the underlying source changed.
 *
 * @returns the fragment including its leading `#`, so it can be appended
 * directly to a workspace URL.
 */
export declare function toDeepLink(selection: WatchSelection): string;
/**
 * Restore a selection from a deep link.
 *
 * Returns null when the fragment is not a Watch link or names no session — a
 * link that cannot identify what it points at should leave the current
 * selection alone rather than clearing it to a half-restored state.
 *
 * Unknown parameters are ignored rather than rejected, so a link produced by a
 * newer build still opens the part this one understands.
 */
export declare function fromDeepLink(fragment: string): WatchSelection | null;
//# sourceMappingURL=selection.d.ts.map