/**
 * Watch records, derived from DeepSeek Harness's own session event log.
 *
 * The single most important thing about this module is what it does *not* do:
 * it does not store anything. DSH already records every Watch tool call and
 * result in the session log it owns, and these are a projection over that log.
 * There is one event store, and it is DSH's.
 *
 * That constraint is what keeps the authority boundaries honest. A second
 * Watch-owned ledger for UI tracking would immediately become a place where
 * evidence could be copied, then edited, then disagree with Watch Core — and
 * the disagreement would be invisible, because both would look authoritative.
 *
 * So what a record carries is **stable foreign identifiers plus presentation
 * metadata**, never a mutable evidence payload. An `evidenceId` is a handle
 * that Watch Core resolves; the text of the evidence lives at Watch Core and
 * is fetched when someone opens it.
 *
 * @module @watchskill/dsh-trajectory/events
 */
import type { Verdict } from '@watchskill/dsh-contracts';
/**
 * The Watch event family.
 *
 * Deliberately small and capability-driven. Each one exists because something
 * in the vertical slice needs to select it, deep-link to it, or replay it.
 */
export type WatchEventType = 
/** A source was attached to this session. */
'source.bound'
/** Watch looked at something and reported what it saw. */
 | 'observation.created'
/** Watch Core minted an evidence record. */
 | 'evidence.created'
/** A verification contract was submitted. */
 | 'verification.requested'
/** A verdict came back. */
 | 'verification.completed'
/** A browser action was sent to the page. */
 | 'browser.action.dispatched'
/** A receipt settled for a browser action. */
 | 'browser.action.receipt'
/** Memory was selected for a turn. */
 | 'memory.context.injected'
/** A memory was corrected. */
 | 'memory.record.corrected'
/** A memory was forgotten. */
 | 'memory.record.forgotten';
/** Every event type, for exhaustive checks and registration. */
export declare const WATCH_EVENT_TYPES: readonly WatchEventType[];
/**
 * Stable references a Watch record carries into Trajectory.
 *
 * All identifiers, no payloads. Every field here is a handle that resolves
 * somewhere with its own authority: DSH owns the session and turn ids, Watch
 * Core owns the source, evidence, verification and receipt ids, and Watch
 * Memory owns the memory id.
 */
export interface WatchRefs {
    /** DSH session this happened in. */
    readonly sessionId: string;
    /** DSH turn, when the event happened inside one. */
    readonly turn: number | null;
    /** DSH step within the turn. */
    readonly step: number | null;
    /** The tool call this record came from. */
    readonly callId: string | null;
    /** Travels with the Bridge request; the same id appears in Core's logs. */
    readonly correlationId: string | null;
    readonly sourceId: string | null;
    /** Which revision of the source. A source that changed is a different one. */
    readonly sourceRevisionId: string | null;
    readonly evidenceIds: readonly string[];
    readonly verificationId: string | null;
    readonly verdict: Verdict | null;
    readonly receiptId: string | null;
    /** Half-open range on the source's own clock, in milliseconds. */
    readonly temporalRange: {
        readonly startMs: number;
        readonly endMs: number;
    } | null;
    /** Artifact handle, resolved by Watch Core when someone opens it. */
    readonly artifactId: string | null;
    readonly memoryIds: readonly string[];
}
/** An empty reference set, so a record never carries `undefined` fields. */
export declare const NO_REFS: WatchRefs;
/**
 * One Watch record as Trajectory shows it.
 *
 * `summary` is the only free text, and it is presentation metadata: a short
 * line a person reads in a ledger. It is derived, never authoritative, and
 * nothing resolves anything from it.
 */
export interface WatchTrajectoryRecord {
    /** Stable within a session; what a deep link points at. */
    readonly recordId: string;
    readonly type: WatchEventType;
    /** DSH log sequence, for ordering against every other Trajectory row. */
    readonly seq: number;
    /** Wall clock, in epoch milliseconds. */
    readonly time: number;
    readonly refs: WatchRefs;
    /** One line for the ledger. Presentation only. */
    readonly summary: string;
    /**
     * Whether this record's detail may be shown without further permission.
     *
     * Memory records about a person can be sensitive, and a ledger is a place
     * people scroll past rather than read carefully. A redacted record still
     * appears — hiding that memory influenced a turn would be worse — but its
     * content is withheld until someone asks for it.
     */
    readonly redacted: boolean;
}
/** The minimum of a DSH session event this module reads. */
export interface SessionEventLike {
    readonly type: string;
    readonly seq: number;
    readonly time: number;
    readonly data: Record<string, unknown>;
}
/**
 * Pull the JSON a Watch tool returned out of a `tool/result` event.
 *
 * Returns null on anything unexpected. A result this cannot read produces no
 * Watch record at all, which is correct: an unreadable result is not evidence
 * that something happened, and inventing a row for it would put a claim in the
 * ledger that nothing backs.
 */
export declare function toolResultValue(event: SessionEventLike): unknown;
/** Whether a tool name belongs to Watch. */
export declare function isWatchTool(name: unknown): boolean;
/** Everything one extraction needs from its surrounding DSH context. */
export interface ExtractionContext {
    readonly sessionId: string;
    readonly turn: number | null;
    readonly step: number | null;
    readonly callId: string | null;
    readonly toolName: string;
    readonly correlationId: string | null;
}
/**
 * Derive Watch records from one Watch tool result.
 *
 * One tool call can produce several records — a query that returns evidence
 * and a verification that returns a verdict are different things to select and
 * to deep-link to, even when they arrived together.
 */
export declare function recordsFromToolResult(event: SessionEventLike, context: ExtractionContext, value: unknown): readonly WatchTrajectoryRecord[];
/**
 * Derive a Watch record from a memory event.
 *
 * Memory is *not* an evidence plane, and these records carry no memory text.
 * What they establish is that memory influenced a turn and which record did
 * it, so a person can follow the id to the Memory surface and correct it
 * there. Sensitive records are marked redacted: the row still appears, because
 * hiding that memory influenced a turn would be worse than showing a withheld
 * one.
 */
export declare function recordFromMemoryEvent(input: {
    readonly kind: 'injected' | 'corrected' | 'forgotten';
    readonly memoryId: string;
    readonly sessionId: string;
    readonly seq: number;
    readonly time: number;
    readonly turn?: number | null;
    /** Why this memory was included. Presentation metadata, never the content. */
    readonly reason?: string;
    readonly sensitive?: boolean;
}): WatchTrajectoryRecord;
//# sourceMappingURL=events.d.ts.map