/**
 * Comparing two observations of the same thing.
 *
 * The question Compare answers is narrower than "what changed", and much more
 * useful: **where did these first stop agreeing?** A diff of two long runs
 * produces hundreds of differences, most of them consequences of the first
 * one, and a person reading it has to work backwards to find the moment that
 * mattered. So the first divergence is a first-class result rather than
 * something to scroll for.
 *
 * Two rules carry over from the rest of the product.
 *
 * **A difference is not a failure.** Most changes between two runs are the
 * change somebody asked for. Compare surfaces divergences; deciding whether
 * one was expected is a verification contract, and Compare never issues a
 * verdict of its own.
 *
 * **Comparison is over identifiers, not content.** Two evidence records are
 * compared by revision, range and digest. Compare holds no evidence payloads,
 * so it cannot become a second place where evidence lives.
 *
 * @module @watchskill/dsh-trajectory/compare
 */
import type { WatchProjection } from './projection.js';
/** What is being compared. */
export type CompareSubject = 
/** Two runs of the same task. */
'run'
/** Two revisions of the same source. */
 | 'source_revision'
/** Two time ranges, in the same source or in two. */
 | 'temporal_region'
/**
 * The same thing before and after a change was made.
 *
 * Named separately from `temporal_region` because it carries an
 * expectation: somebody did something in between, and the question is
 * whether the difference is the one they intended. Compare still issues no
 * verdict — that remains a verification contract — but the surface reads
 * differently when it knows a change was deliberate.
 */
 | 'before_after';
/** Every subject, for enumerating the picker. */
export declare const COMPARE_SUBJECTS: readonly CompareSubject[];
/** Which signal a divergence was found in. */
export type DivergenceChannel = 'visual' | 'text' | 'ocr' | 'transcript' | 'dom' | 'network' | 'console' | 'verification' | 'receipt';
/** How the two sides differ. */
export type DivergenceKind = 
/** Present on the left, absent on the right. */
'removed'
/** Absent on the left, present on the right. */
 | 'added'
/** Present on both, different. */
 | 'changed'
/** Present on both, and the difference is only in timing. */
 | 'retimed';
/** One place two sides stopped agreeing. */
export interface Divergence {
    readonly channel: DivergenceChannel;
    readonly kind: DivergenceKind;
    /** Where in the source, so the player can go there. */
    readonly atMs: number | null;
    /** The record on each side, by id. Never the content. */
    readonly leftRecordId: string | null;
    readonly rightRecordId: string | null;
    readonly leftEvidenceId: string | null;
    readonly rightEvidenceId: string | null;
    /** One line for a list. Presentation only; nothing resolves from it. */
    readonly summary: string;
}
/** The result of comparing two sides. */
export interface Comparison {
    readonly subject: CompareSubject;
    readonly leftId: string;
    readonly rightId: string;
    readonly divergences: readonly Divergence[];
    /**
     * The earliest divergence, or null when the two agree.
     *
     * The answer people actually want. Everything after the first divergence is
     * usually a consequence of it, and presenting a hundred differences equally
     * makes the one that mattered harder to find, not easier.
     */
    readonly firstDivergence: Divergence | null;
    /** Records present on both sides and identical. */
    readonly agreements: number;
}
/**
 * The minimum of an evidence record Compare needs to place it on a channel.
 *
 * A structural subset rather than an import of `EvidenceRecord`: the
 * trajectory package holds no evidence payloads, and taking the full type here
 * would invite one to be stored.
 */
export interface ChannelHint {
    readonly modality: 'visual' | 'text' | 'audio' | 'dom' | 'network' | 'filesystem';
}
/** Evidence ids to what sense produced them, when the caller has resolved any. */
export type ChannelHints = ReadonlyMap<string, ChannelHint>;
/**
 * Compare two projections.
 *
 * Pure, and deterministic for the same inputs — which is what lets a
 * comparison be deep-linked and replayed like anything else in the product.
 *
 * @param subject - what the two sides are: two runs, two revisions, two regions.
 */
export declare function compareProjections(left: WatchProjection, right: WatchProjection, subject: CompareSubject, ids: {
    readonly leftId: string;
    readonly rightId: string;
}, hints?: ChannelHints): Comparison;
/**
 * Whether a comparison found a change in what was *established*.
 *
 * Separate from "found any difference" on purpose. Two runs producing
 * different evidence at a different moment is normal; two runs reaching
 * different verdicts is the thing somebody needs to look at.
 */
export declare function hasVerdictDivergence(comparison: Comparison): boolean;
/**
 * A stable digest of a comparison.
 *
 * Same inputs, same digest — so a comparison can be deep-linked, replayed and
 * checked for change the same way a projection can. Over identifiers and kinds
 * only, never over the summary text.
 */
export declare function comparisonDigest(comparison: Comparison): string;
/**
 * The first divergence that changed what was *established*.
 *
 * Distinct from `firstDivergence`, and the distinction is the useful one. The
 * earliest difference between two runs is frequently a timestamp or an extra
 * frame; the earliest difference in a verdict or a receipt is the moment the
 * two runs stopped being the same outcome. A surface that offered only the
 * first would send people to the wrong second.
 */
export declare function firstMeaningfulDivergence(comparison: Comparison): Divergence | null;
/**
 * A deep link to one side of a divergence.
 *
 * Built from the same selection model everything else in the product uses, so
 * a link out of Compare opens the same inspector a link out of Trajectory
 * would. Returns null when the side has nothing to point at, rather than a
 * link that resolves to an empty panel.
 */
export declare function divergenceLink(comparison: Comparison, divergence: Divergence, side: 'left' | 'right', context: {
    readonly workspaceId: string;
    readonly sessionId: string;
}): string | null;
/**
 * A portable comparison.
 *
 * Identifiers, kinds and links — never evidence content, for the same reason
 * `Divergence` carries none. An exported bundle that inlined what it compared
 * would be a second copy of the evidence, and a second copy is one nobody can
 * invalidate.
 */
export interface ComparisonBundle {
    readonly digest: string;
    readonly subject: CompareSubject;
    readonly leftId: string;
    readonly rightId: string;
    readonly agreements: number;
    readonly divergences: readonly Divergence[];
    readonly firstDivergence: Divergence | null;
    readonly firstMeaningfulDivergence: Divergence | null;
    readonly links: readonly {
        readonly side: 'left' | 'right';
        readonly link: string;
    }[];
}
/** Freeze a comparison into something that can be attached to a report. */
export declare function exportComparison(comparison: Comparison, context: {
    readonly workspaceId: string;
    readonly sessionId: string;
}): ComparisonBundle;
/**
 * One line summarizing a comparison.
 *
 * Deliberately never says "passed" or "failed". Compare reports where two
 * things stopped agreeing; whether that was the change somebody asked for is a
 * verification contract, and a summary that editorialized would be Compare
 * issuing the verdict it is not allowed to issue.
 */
export declare function describeComparison(comparison: Comparison): string;
//# sourceMappingURL=compare.d.ts.map