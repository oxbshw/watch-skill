/**
 * The Watch projection over DSH's session log, and its replay guarantee.
 *
 * Replay is the property that makes a receipt worth anything. If reopening a
 * finished session could produce a different picture of it, then the picture
 * is an opinion rather than a record, and a verdict shown in it proves nothing
 * about what happened at the time.
 *
 * So this is a pure fold: the same events in, the same projection out, with no
 * clock read, no network, no model, and nothing regenerated. `projectionHash`
 * makes that assertable rather than assumed — two runs over the same log
 * produce the same hash, and a change to what a record carries changes it.
 *
 * @module @watchskill/dsh-trajectory/projection
 */
import type { SessionEventLike, WatchTrajectoryRecord } from './events.js';
/** The Watch view of one session. */
export interface WatchProjection {
    readonly sessionId: string;
    /** Records in log order. Ordering is by DSH sequence, never by wall clock. */
    readonly records: readonly WatchTrajectoryRecord[];
    /** Evidence id to the record that produced it, for citation resolution. */
    readonly byEvidence: ReadonlyMap<string, WatchTrajectoryRecord>;
    /** Record id to record, for deep-link restoration. */
    readonly byRecord: ReadonlyMap<string, WatchTrajectoryRecord>;
}
/** An empty projection, so a session with no Watch activity is still a value. */
export declare function emptyProjection(sessionId: string): WatchProjection;
/**
 * Fold a session's events into the Watch projection.
 *
 * Deliberately takes the events rather than a live session: the same function
 * serves the live view and replay, so there is no second code path whose
 * output could differ from the one people trust.
 *
 * @param events - DSH session events in ascending sequence order.
 * @param sessionId - the session these belong to.
 */
export declare function project(events: readonly SessionEventLike[], sessionId: string): WatchProjection;
/**
 * Merge externally-produced records into a projection.
 *
 * Memory records do not come from tool results — memory influences a turn
 * without the agent calling anything — so they are contributed rather than
 * derived. They are sorted into the same sequence order so the ledger stays
 * one chronology rather than two lists shown together.
 */
export declare function withRecords(projection: WatchProjection, extra: readonly WatchTrajectoryRecord[]): WatchProjection;
/**
 * A stable hash of what a projection contains.
 *
 * Over the identifiers and the verdict, not over wall-clock times or free
 * text: a replay that produced the same records at the same sequence numbers
 * with the same verdicts *is* the same projection, and a hash that also
 * covered the summary line would fail whenever someone improved the wording.
 *
 * Not cryptographic, and not trying to be. It exists to catch a projection
 * that changed, not to resist someone forging one.
 */
export declare function projectionHash(projection: WatchProjection): string;
/**
 * Resolve a deep-linked selection against a projection.
 *
 * Returns the record a link points at, preferring the record id and falling
 * back to the evidence id — a link made before a record id changed still opens
 * the right evidence, which is the part a person cared about.
 */
export declare function resolveRecord(projection: WatchProjection, selection: {
    readonly recordId: string | null;
    readonly evidenceId: string | null;
}): WatchTrajectoryRecord | null;
//# sourceMappingURL=projection.d.ts.map