/**
 * The one selection every Watch surface reads and writes.
 *
 * DSH's Trajectory selection is documented as local to Trajectory, with no
 * anchor deep links. This is the smallest additive extension around that: a
 * Watch-owned service holding the canonical selection for Watch-related
 * records, which surfaces subscribe to. Nothing upstream is replaced — DSH
 * keeps its own local selection, and Watch drives it from here.
 *
 * A store rather than a value, because several panels need to observe the same
 * change; but the value it holds is the pure `WatchSelection` from
 * `@watchskill/dsh-trajectory`, so every rule about what a selection means
 * stays testable without a browser.
 *
 * @module @watchskill/dsh-trajectory/selection-store
 */
import type { WatchSelection } from './selection.js';
import type { WatchProjection } from './projection.js';
/** Notified whenever the selection changes. */
export type SelectionListener = (selection: WatchSelection) => void;
/**
 * Holds the canonical Watch selection for one workspace.
 *
 * Deliberately has no knowledge of panels. A panel subscribes and renders; it
 * never asks another panel what is selected, which is what stops the panels
 * from disagreeing.
 */
export declare class WatchSelectionStore {
    private current;
    private readonly listeners;
    /** The latest projection, so a deep link can resolve without a round trip. */
    private projection;
    constructor(workspaceId: string, sessionId: string);
    /** The current selection. Always a value; never undefined. */
    get(): WatchSelection;
    /**
     * Replace the selection.
     *
     * A selection identical to the current one is dropped rather than
     * broadcast. Panels both read and write this store, so an echo would loop:
     * a panel reacts to its own change, re-selects, and notifies again.
     */
    set(selection: WatchSelection): void;
    /** Subscribe; returns an unsubscribe function. */
    subscribe(listener: SelectionListener): () => void;
    /** Publish the projection a deep link should resolve against. */
    setProjection(projection: WatchProjection): void;
    /** The current projection, or null before the session has loaded. */
    getProjection(): WatchProjection | null;
    /** A link that restores the current selection. */
    link(): string;
    /**
     * Restore a selection from a link.
     *
     * @returns whether the fragment was a Watch link that named a session. A
     * fragment that is not one leaves the selection alone rather than clearing
     * it to a half-restored state.
     */
    restore(fragment: string): boolean;
    /** Release every subscriber. Called when the plugin unloads. */
    dispose(): void;
}
//# sourceMappingURL=selection-store.d.ts.map