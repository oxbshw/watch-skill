/**
 * Watch capabilities as DeepSeek Harness agent tools.
 *
 * This is the seam that makes Watch reachable from the agent loop. Everything
 * else — the inspector, the timeline, the receipts — is presentation over what
 * these calls return.
 *
 * Two rules shape every tool here:
 *
 * 1. A tool never reports more certainty than Watch Core gave it. An answer
 *    with citations is an *evidence-linked* answer, not a verified one. Only
 *    `watch_verify` can produce a verdict, and only Watch Core can mint it
 *    (ADR-002).
 * 2. A missing capability is a stated refusal with a fix, never a silent
 *    fallback to guessing from the conversation. The model is told, in its
 *    system prompt, that this is the contract.
 *
 * @module @watchskill/dsh-tools
 */
import type { Context } from '@deepseek-ai/cordis';
import s from '@deepseek-ai/schemastery';
export { SENSORY_GUIDANCE, applySensoryTools } from './sensory.js';
export { applyMemory } from './memory.js';
export { BROWSER_GUIDANCE, applyBrowserTools } from './browser.js';
export type { BrowserConfig } from './browser.js';
export type { SensoryConfig } from './sensory.js';
export declare const name = "watch-tools";
export declare const inject: string[];
/** Deployment policy for the Watch tool surface. */
export interface Config {
    /** Deadline for a source query, which may involve perception work. */
    readonly queryTimeoutMs: number;
    /** Deadline for one verification contract. */
    readonly verifyTimeoutMs: number;
    /** Deadline for a search or a moment lookup. */
    readonly readTimeoutMs: number;
    /** Deadline for starting a live session, which may launch a browser. */
    readonly liveStartTimeoutMs: number;
    /** Deadline for one browser action, including its re-observation. */
    readonly actTimeoutMs: number;
    /** Deadline for a page observation. */
    readonly observeTimeoutMs: number;
}
/** Schemastery validation for the tool-surface policy. */
export declare const Config: s<Config>;
/** Register the Watch tool surface and the guidance that governs its use. */
export declare function apply(ctx: Context, config: Config): void;
/**
 * The plugin, as the Cordis loader resolves it.
 *
 * An object rather than the bare `apply` function, and that distinction is the
 * whole reason this exists. The loader takes `module.default` and then reads
 * `plugin.inject` off it — so a default export of the function alone leaves the
 * named `inject` sitting on the module namespace where nothing looks, and the
 * first `ctx.systemPrompt` access throws "cannot get property without inject"
 * at boot.
 *
 * Nothing catches that before a real boot: the composed tree is correct, the
 * install smoke passes, and the profile fails the moment it actually starts.
 * `scripts/boot-smoke.mjs` is the gate that does catch it.
 */
declare const _default: {
    name: string;
    inject: string[];
    apply: typeof apply;
};
export default _default;
//# sourceMappingURL=index.d.ts.map