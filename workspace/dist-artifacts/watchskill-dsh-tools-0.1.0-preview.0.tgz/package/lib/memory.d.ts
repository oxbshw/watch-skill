/**
 * Mounting memory into the agent loop.
 *
 * `@watchskill/dsh-memory` owns what a memory is and what may be done with
 * one; this connects it to DSH — registering the tools with the real
 * `defineTool`, and putting the compiled context into the system prompt.
 *
 * The dependency runs this way round on purpose. Memory is useful headless,
 * and a memory package that could not be loaded without a tool runtime would
 * not be — so it takes `defineTool` as an argument and this file supplies it.
 *
 * @module @watchskill/dsh-tools/memory
 */
import type { Context } from '@deepseek-ai/cordis';
/**
 * Register the memory tools and the per-turn context section.
 *
 * The section is a function of the turn, not a fixed string: it is recompiled
 * each time it is read, which is what makes a correction take effect on the
 * very next turn rather than at the next restart.
 */
export declare function applyMemory(ctx: Context): void;
//# sourceMappingURL=memory.d.ts.map