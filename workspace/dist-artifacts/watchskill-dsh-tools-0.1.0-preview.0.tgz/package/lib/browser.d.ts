/**
 * The browser Operator as agent tools.
 *
 * This is the surface the product's central claim is about. An agent clicks a
 * button, the page shows a success banner, the network returned 500, and Watch
 * declines to call that a success.
 *
 * The tools are shaped so that outcome is the default rather than something a
 * careful caller opts into:
 *
 * - acting requires an expectation, and an action without one comes back
 *   `unverified` — not a success;
 * - acting requires an idempotency key, minted here rather than by the model,
 *   so a reconnect replays the receipt instead of pressing the button again;
 * - a consequential action requires an approval reference, and the Bridge
 *   refuses without one before the page is touched.
 *
 * @module @watchskill/dsh-tools/browser
 */
import type { Context } from '@deepseek-ai/cordis';
/** Deployment policy for the browser tools. */
export interface BrowserConfig {
    /** Deadline for one browser action, including its re-observation. */
    readonly actTimeoutMs: number;
    /** Deadline for a page observation. */
    readonly observeTimeoutMs: number;
}
/**
 * What the model is told about acting on a page.
 *
 * The rules are stated as the loop rather than as prohibitions, because the
 * loop is what produces a receipt worth reading, and an agent that follows it
 * cannot easily produce a false success even by accident.
 */
export declare const BROWSER_GUIDANCE = "## Watch: acting on a page, and proving it worked\n\nEvery action follows the same cycle. Skipping a step does not make it faster,\nit makes the result unprovable.\n\n    observe \u2192 state what should change \u2192 act \u2192 re-observe \u2192 read the verdict\n\n- Call `watch_browser_observe` before acting. Deciding what to click from a\n  screenshot you took three steps ago is how an agent clicks the wrong thing.\n- State the expectation before you act, in `expect`. Name what should be\n  observable afterwards \u2014 the text that should appear, the row that should be\n  gone, the field that should hold a value. An action with no expectation\n  comes back `unverified`, which is honest and is not a success.\n- Describe the target the way a person would: its role and accessible name, its\n  label, its visible text. Do not reach for pixel coordinates unless nothing\n  else identifies it; the receipt records which strategy resolved the target,\n  and \"found by accessible name\" and \"found at (412, 380)\" are very different\n  claims about the same click.\n- If the target is ambiguous, the action is refused rather than guessed. Narrow\n  the description instead of retrying the same one.\n- **A dispatched action is not a completed effect.** The tool returning without\n  an error means the click was delivered. Whether anything happened is what the\n  verdict says. Report `unverified` and `failed` as themselves.\n- Anything that could change server state needs the person's approval first,\n  and the tool will refuse without it. That includes most clicks: the runtime\n  cannot tell a search button from a payment button, so it assumes the second.\n- After a timeout, do **not** act again. Call `watch_browser_receipt` with the\n  same idempotency key to find out what actually happened.";
/** Register the browser observe, act and receipt tools. */
export declare function applyBrowserTools(ctx: Context, config: BrowserConfig): void;
//# sourceMappingURL=browser.d.ts.map