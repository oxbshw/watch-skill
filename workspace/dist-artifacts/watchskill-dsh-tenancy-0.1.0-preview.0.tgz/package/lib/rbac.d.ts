/**
 * What a role may do, decided in one place, on the server.
 *
 * The permission catalogue below is the whole of it. There is no second table,
 * no per-endpoint improvisation, and no client-side check that a server-side
 * check does not repeat — a UI that hides a button is a courtesy, and treating
 * it as a control is how an API ends up open.
 *
 * Two properties are enforced structurally rather than by convention.
 *
 * **Every decision runs the tenant check first.** {@link authorize} takes the
 * owner as a required argument, so there is no shape of call that checks a role
 * without checking whose resource it is. A permission function that took only
 * a role would be the one somebody eventually calls.
 *
 * **Personal resources are not reachable by administration.** An admin of a
 * workspace is not an administrator of the people in it. Another member's taste
 * is denied at a rank above the role check, so no role can be added that would
 * reach it.
 *
 * @module @watchskill/dsh-tenancy/rbac
 */
import { type AccessDecision, type Directory, type Principal, type ResourceOwner, type Role } from './identity.js';
/** Everything a principal can be authorized to do. */
export type Permission = 'workspace.read' | 'workspace.manage' | 'source.read' | 'source.write' | 'evidence.read' | 'artifact.read' | 'memory.read' | 'memory.write'
/** Changing something in the *shared* memory scope. */
 | 'memory.shared.mutate' | 'browser.operate' | 'credential.use' | 'plugin.manage' | 'export.perform' | 'verification.policy.administer' | 'comment.write' | 'worker.submit' | 'audit.read';
/** Every permission, for enumerating a role editor. */
export declare const PERMISSIONS: readonly Permission[];
/**
 * The minimum role each permission requires.
 *
 * Written as one table so the whole authorization model is readable at once.
 * Anything that changes the world, spends money, or moves data out sits at
 * `admin` or above — not because members are untrusted, but because those are
 * the actions whose blast radius is the tenant rather than the session.
 */
export declare const REQUIRED_ROLE: Readonly<Record<Permission, Role>>;
/**
 * Permissions that reach a person rather than a workspace.
 *
 * Listed so the rule is checkable directly: for these, ownership by another
 * user is denied before the role is even consulted.
 */
export declare const PERSONAL_PERMISSIONS: readonly Permission[];
/** What was asked for. */
export interface AuthorizationRequest {
    readonly principal: Principal;
    readonly permission: Permission;
    readonly owner: ResourceOwner;
    readonly directory: Directory;
}
/**
 * Decide one request.
 *
 * The order is the security property, and each step answers something the next
 * one would otherwise have to assume:
 *
 * 1. **Tenant.** A resource in another tenant does not exist.
 * 2. **Liveness.** Revocation and deletion are checked per request, not at
 *    sign-in, so an offboarding takes effect on the next call.
 * 3. **Personal ownership.** Another person's memory is theirs, whatever role
 *    the principal holds in the workspace it happens to sit beside.
 * 4. **Membership.** No membership, no access — including for a tenant owner,
 *    who has to join a workspace like anybody else.
 * 5. **Role.** Finally, is the role strong enough.
 */
export declare function authorize(request: AuthorizationRequest): AccessDecision;
/** The strongest role a principal holds anywhere in their tenant. */
export declare function strongestRole(principal: Principal): Role | null;
/**
 * Filter a list to what a principal may see.
 *
 * Used everywhere a collection is served. Filtering rather than refusing is
 * right for a list — a search that returned an error because one result was
 * out of scope would be unusable — but the filter has to be the same
 * `authorize` every single-resource read uses, or the two drift and the list
 * becomes the way around the check.
 */
export declare function filterAuthorized<T>(items: readonly T[], ownerOf: (item: T) => ResourceOwner, request: Omit<AuthorizationRequest, 'owner'>): readonly T[];
/**
 * Whether a permission may be delegated by a principal holding one role.
 *
 * A member cannot grant admin. Privilege escalation through invitation is the
 * oldest hole in every collaboration product, and the rule that closes it is
 * that you may only grant what you already hold.
 */
export declare function mayGrant(granter: Role, granted: Role): boolean;
//# sourceMappingURL=rbac.d.ts.map