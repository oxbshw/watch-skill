/**
 * The audit log, and the two things it must never contain.
 *
 * An audit log exists so somebody can reconstruct what happened after the fact.
 * That makes it the single most attractive place in the system to put "just a
 * bit more context", and the single worst place for that instinct to win —
 * because an audit log is retained longer than anything else, read by more
 * people than anything else, and exported to places nobody was thinking about
 * when the entry was written.
 *
 * So two rules are enforced here rather than reviewed:
 *
 * **No raw credential, ever.** {@link record} refuses an entry whose detail
 * looks like a secret. Not redacts — refuses, and throws, because a silently
 * redacted audit entry is one nobody notices was nearly a disclosure.
 *
 * **No memory content beyond what the event is about.** A memory mutation is
 * audited as an id, a kind and an actor. Logging the sentence that was
 * forgotten would mean the deletion did not delete it, and the place it
 * survived would be the log nobody thinks to check.
 *
 * @module @watchskill/dsh-tenancy/audit
 */
/** What gets audited. Every entry is one of these; there is no `other`. */
export type AuditAction = 'auth.login' | 'auth.logout' | 'auth.failed' | 'permission.granted' | 'permission.revoked' | 'membership.added' | 'membership.removed' | 'credential.used' | 'egress.sensitive' | 'browser.side_effect' | 'memory.mutated' | 'memory.scope_moved' | 'plugin.installed' | 'plugin.removed' | 'export.performed' | 'verification.policy_changed' | 'share.granted' | 'share.revoked' | 'tenant.deleted' | 'access.denied';
/** Every audited action, so a retention policy can enumerate them. */
export declare const AUDIT_ACTIONS: readonly AuditAction[];
/** One audit entry. */
export interface AuditEntry {
    readonly entryId: string;
    readonly tenantId: string;
    readonly at: string;
    readonly action: AuditAction;
    /** Who did it. Null for a system action. */
    readonly actorUserId: string | null;
    readonly workspaceId: string | null;
    /** What it was done to, as an id. */
    readonly subjectId: string | null;
    readonly subjectKind: string | null;
    /**
     * Detail, as scalars.
     *
     * Deliberately not free text and deliberately not nested: a flat record of
     * short scalars is checkable, and a nested blob is where a payload hides.
     */
    readonly detail: Readonly<Record<string, string | number | boolean>>;
    /** Correlates with a Bridge request and a receipt. */
    readonly correlationId: string | null;
}
/** Whether a value looks like a secret. */
export declare function looksLikeSecret(value: string): boolean;
/** Why an entry was refused. */
export declare class AuditRefusal extends Error {
    readonly field: string;
    constructor(field: string, message: string);
}
/** An append-only audit log, scoped per tenant on read. */
export declare class AuditLog {
    private readonly entries;
    private sequence;
    /**
     * Record one entry, or refuse it.
     *
     * Throws rather than redacting. A redaction here would be silent, and the
     * caller that nearly wrote a token into the audit log is exactly the caller
     * who needs to find out.
     */
    record(entry: Omit<AuditEntry, 'entryId'>): AuditEntry;
    /**
     * Read one tenant's audit trail.
     *
     * Tenant-scoped at the query rather than filtered by the caller. A log that
     * returned everything and trusted its callers to filter would leak the first
     * time somebody wrote a new report.
     */
    forTenant(tenantId: string): readonly AuditEntry[];
    /** Entries about one subject, within one tenant. */
    forSubject(tenantId: string, subjectId: string): readonly AuditEntry[];
    /** How many entries exist in total. For diagnostics, never for a report. */
    size(): number;
}
/**
 * Audit a credential use without auditing the credential.
 *
 * The reference is a handle into DSH's own credential store — Watch never
 * holds a secret — so the entry says which connection was used, by whom, for
 * what, and nothing that could be replayed.
 */
export declare function credentialUse(input: {
    readonly tenantId: string;
    readonly workspaceId: string | null;
    readonly actorUserId: string;
    readonly connectionId: string;
    readonly purpose: string;
    readonly at: string;
    readonly correlationId: string | null;
}): Omit<AuditEntry, 'entryId'>;
/**
 * Audit a memory mutation without auditing the memory.
 *
 * Ids and kinds only. An audit trail of what was forgotten, containing what
 * was forgotten, is not a deletion — and the log is precisely where that
 * mistake survives longest.
 */
export declare function memoryMutation(input: {
    readonly tenantId: string;
    readonly workspaceId: string | null;
    readonly actorUserId: string | null;
    readonly memoryId: string;
    readonly kind: string;
    readonly operation: string;
    readonly at: string;
}): Omit<AuditEntry, 'entryId'>;
/**
 * Audit a refused access.
 *
 * Denials are audited as carefully as grants, because a run of them is the
 * clearest signal there is that somebody is enumerating ids. The denial code
 * is recorded; the resource that was asked for is recorded as an id, so a
 * cross-tenant attempt is visible without the log itself becoming the oracle.
 */
export declare function accessDenied(input: {
    readonly tenantId: string;
    readonly actorUserId: string;
    readonly permission: string;
    readonly code: string;
    readonly subjectId: string;
    readonly subjectKind: string;
    readonly at: string;
}): Omit<AuditEntry, 'entryId'>;
//# sourceMappingURL=audit.d.ts.map