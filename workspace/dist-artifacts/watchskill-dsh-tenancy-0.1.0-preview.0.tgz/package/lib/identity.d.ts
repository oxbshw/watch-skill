/**
 * Who owns what, and the rule that makes multi-tenancy real.
 *
 * A login screen is not multi-tenancy. Multi-tenancy is the property that every
 * persisted and served resource carries an explicit owner, and that no code
 * path returns one without checking it. The difference shows up the first time
 * somebody guesses an id, and by then it is a disclosure rather than a bug.
 *
 * So the model here is deliberately blunt. Every resource has a
 * {@link ResourceOwner}, every owner names a tenant, and {@link sameTenant} is
 * the check that stands between a request and an answer. There is no "public"
 * resource, no "system" tenant that can read everything, and no ambient
 * fallback when the owner is unknown — an unowned resource is unreachable, and
 * that is the safe direction to fail in.
 *
 * The hierarchy is a hierarchy, not a set of parallel ids:
 *
 *   tenant → workspace → session/source/evidence/memory
 *   tenant → user → membership(role, workspace)
 *
 * A user belongs to exactly one tenant. Cross-tenant users are the feature that
 * turns every access check into a question about which identity is currently
 * in play, and the answer is wrong exactly once before it matters.
 *
 * @module @watchskill/dsh-tenancy/identity
 */
/** A tenant: the boundary nothing crosses without an explicit share. */
export interface Tenant {
    readonly tenantId: string;
    readonly displayName: string;
    /** Set when the tenant has been deleted; nothing under it is servable. */
    readonly deletedAt: string | null;
}
/** A person, inside exactly one tenant. */
export interface User {
    readonly userId: string;
    readonly tenantId: string;
    readonly displayName: string;
    /** Set when access has been revoked; every check fails from that moment. */
    readonly revokedAt: string | null;
}
/** A workspace, inside exactly one tenant. */
export interface Workspace {
    readonly workspaceId: string;
    readonly tenantId: string;
    readonly displayName: string;
    readonly deletedAt: string | null;
}
/** What a member may do. */
export type Role = 
/** Everything, including tenant administration. */
'owner'
/** Everything inside a workspace, including sharing and policy. */
 | 'admin'
/** Ordinary work: observe, act with approval, contribute memory. */
 | 'member'
/** Read what is shared, comment, and nothing else. */
 | 'reviewer'
/** Read what is shared. */
 | 'viewer';
/** Every role, strongest first. */
export declare const ROLES: readonly Role[];
/** One person's membership of one workspace. */
export interface Membership {
    readonly userId: string;
    readonly tenantId: string;
    readonly workspaceId: string;
    readonly role: Role;
    readonly grantedAt: string;
    readonly revokedAt: string | null;
}
/** The kinds of thing that can be owned. */
export type ResourceKind = 'workspace' | 'session' | 'source' | 'evidence' | 'artifact' | 'memory' | 'credential' | 'worker_job' | 'collection' | 'comment';
/**
 * Who a resource belongs to.
 *
 * `workspaceId` is null for something owned by a tenant directly (a
 * credential, a worker job). `userId` is set only for things that are
 * personal — a taste memory belongs to a person, not to their workspace, and
 * that distinction is what keeps personal taste out of a shared scope.
 */
export interface ResourceOwner {
    readonly kind: ResourceKind;
    readonly resourceId: string;
    readonly tenantId: string;
    readonly workspaceId: string | null;
    readonly userId: string | null;
}
/** The identity a request is made under. */
export interface Principal {
    readonly userId: string;
    readonly tenantId: string;
    /** Memberships this principal holds, already loaded. */
    readonly memberships: readonly Membership[];
}
/** Why an access check failed. */
export interface AccessDenial {
    readonly reason: string;
    /** A stable code, for the audit log. */
    readonly code: 'cross_tenant' | 'no_membership' | 'role_insufficient' | 'not_owner' | 'revoked' | 'deleted' | 'unowned';
}
/** The outcome of an access check. */
export type AccessDecision = {
    readonly allowed: true;
} | {
    readonly allowed: false;
    readonly denial: AccessDenial;
};
/** Allow, as a shared value. */
export declare const ALLOWED: AccessDecision;
/** Deny with a code and a reason. */
export declare function deny(code: AccessDenial['code'], reason: string): AccessDecision;
/**
 * The first and most important check.
 *
 * Called before anything else, everywhere. A resource in another tenant does
 * not produce a "not permitted" — as far as the principal is concerned it does
 * not exist, and the denial reason says nothing about it.
 */
export declare function sameTenant(principal: Principal, owner: ResourceOwner): AccessDecision;
/** The membership a principal holds for one workspace, if any. */
export declare function membershipFor(principal: Principal, workspaceId: string): Membership | null;
/** Whether one role is at least as strong as another. */
export declare function atLeast(held: Role, required: Role): boolean;
/**
 * Whether a resource is personal to somebody other than the principal.
 *
 * The rule behind "personal taste is private by default": a resource with a
 * `userId` belongs to that person, and workspace membership does not reach it.
 * An admin cannot read another member's taste, which is deliberate — an
 * administrator of a workspace is not an administrator of a person.
 */
export declare function isOtherPersonsPersonal(principal: Principal, owner: ResourceOwner): boolean;
/** The state of the world an access check reads. */
export interface Directory {
    readonly tenants: ReadonlyMap<string, Tenant>;
    readonly users: ReadonlyMap<string, User>;
    readonly workspaces: ReadonlyMap<string, Workspace>;
}
/**
 * Whether the principal, the tenant and the workspace are all still live.
 *
 * Revocation and deletion are checked on every request rather than at login.
 * A session that outlived a revocation is the thing an offboarding process is
 * supposed to prevent, and checking once at sign-in means it does not.
 */
export declare function isLive(principal: Principal, owner: ResourceOwner, directory: Directory): AccessDecision;
//# sourceMappingURL=identity.d.ts.map