/**
 * LLMWiki compatibility: five files in, five files out, no authority moved.
 *
 * LLMWiki's shape — raw, wiki, citations, index, log — is a good one, and
 * being able to read and write it means a workspace is not trapped here. That
 * is the whole reason this adapter exists, and it is optional in both
 * directions: nothing in Watch requires it, and nothing about importing a
 * bundle makes LLMWiki the authority for anything.
 *
 * The asymmetry is deliberate and is the only interesting thing in the module.
 *
 * **Export is lossless about provenance and lossy about nothing else.** Every
 * exported statement carries its memory id, and `citations` carries the
 * evidence refs, so a bundle that leaves here can be read by something else
 * without the reader having to trust a sentence with no source.
 *
 * **Import is lossy on purpose.** Everything imported arrives as `imported`
 * origin at low confidence, whatever the bundle claims. A bundle that says a
 * statement is `explicit_user`, or high confidence, or already verified, is a
 * bundle making claims about a person it has never met. Those fields are read
 * and discarded rather than trusted, and the discarding is tested with a
 * bundle that asserts all of them at once.
 *
 * @module @watchskill/dsh-adapters/llmwiki
 */
import type { MemoryEvent, MemoryRecord } from '@watchskill/dsh-memory';
/** The five files an LLMWiki bundle carries. */
export interface LlmWikiBundle {
    /** Statements as they were captured, one per line, with provenance markers. */
    readonly raw: string;
    /** The readable pages. */
    readonly wiki: string;
    /** Evidence references, one per line. */
    readonly citations: string;
    /** What is in the bundle, by kind. */
    readonly index: string;
    /** What happened, by id and kind. Never content. */
    readonly log: string;
}
/** One statement, as the bundle format carries it. */
export interface LlmWikiStatement {
    readonly id: string;
    readonly kind: string;
    readonly text: string;
    /** What the bundle claims. Read, reported, and never trusted on import. */
    readonly claimedOrigin: string | null;
    readonly claimedConfidence: number | null;
    readonly evidenceRefs: readonly string[];
}
/** Parse one statement line back. */
export declare function parseStatement(line: string): LlmWikiStatement | null;
/**
 * Export a bundle.
 *
 * Deterministic: the same records and events produce the same five files, so
 * two exports of an unchanged workspace are identical and a diff between them
 * is a real change rather than a reordering.
 */
export declare function toLlmWiki(records: readonly MemoryRecord[], events?: readonly MemoryEvent[]): LlmWikiBundle;
/** Why an imported statement was refused. */
export interface ImportRefusal {
    readonly statement: LlmWikiStatement;
    readonly reason: string;
}
/** A candidate the ledger may consider, produced from an imported statement. */
export interface ImportedStatement {
    readonly kind: MemoryRecord['kind'];
    readonly content: string;
    readonly origin: 'imported';
    readonly confidence: number;
    readonly sourceRefs: readonly string[];
    readonly evidenceRefs: readonly string[];
    /** What the bundle claimed, kept for the review UI. Never acted on. */
    readonly claimed: {
        readonly origin: string | null;
        readonly confidence: number | null;
    };
}
/** The outcome of reading a bundle. */
export interface ImportResult {
    readonly accepted: readonly ImportedStatement[];
    readonly refused: readonly ImportRefusal[];
    /** One line for the import dialog. */
    readonly summary: string;
}
/**
 * Read a bundle.
 *
 * Every accepted statement comes back as `imported` at a fixed low confidence.
 * The claimed origin and confidence travel alongside, so a review surface can
 * show "this bundle says you stated it" without the ledger acting on it —
 * which is the difference between reporting a claim and believing one.
 *
 * The refusals are the same two the wiki import uses, for the same reason: a
 * bundle is a file, and a file that could grant a permission or assert
 * something about a protected subject is a file that writes itself into
 * authority.
 */
export declare function fromLlmWiki(bundle: LlmWikiBundle): ImportResult;
/**
 * Whether a round trip preserved what it should.
 *
 * Checks content and evidence refs, and deliberately does *not* check origin or
 * confidence — those are supposed to be lost on import, and a round-trip test
 * that required them to survive would be a test demanding the vulnerability.
 */
export declare function roundTripPreservesContent(original: readonly MemoryRecord[], imported: readonly ImportedStatement[]): boolean;
/** What this adapter can claim. Optional, and never an authority. */
export declare function llmWikiAvailability(): {
    readonly adapterId: string;
    readonly optional: true;
    readonly proven: readonly string[];
    readonly notMachineTested: readonly string[];
};
//# sourceMappingURL=llmwiki.d.ts.map