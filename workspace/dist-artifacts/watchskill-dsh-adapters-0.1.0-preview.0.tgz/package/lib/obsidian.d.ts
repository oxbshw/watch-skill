/**
 * The Obsidian adapter: optional, one-directional about authority, and inert.
 *
 * Obsidian is a good place to read a workspace wiki and a terrible place to
 * keep the record of what an agent believes. It is a folder of Markdown that
 * anything can write to — a sync client, a plugin, a shared drive, another
 * person — and the thing that makes it pleasant is exactly the thing that
 * makes it unsuitable as an authority.
 *
 * So this adapter does two things and refuses a third.
 *
 * It **exports** a vault: the generated wiki, plus the frontmatter and
 * wikilinks that make Obsidian's graph and backlinks work. It **imports** an
 * edit as a *proposal*, through the same validation a hand-edited wiki page
 * goes through. It never lets vault content become authority — not evidence,
 * not a verdict, not `explicit_user`, not a permission, not a scope change.
 *
 * Nothing in Watch Core depends on this module, and nothing here imports
 * Obsidian. There is no Obsidian API to import; the integration surface is a
 * folder and a URI scheme, which is why the adapter can be tested completely
 * against a filesystem-shaped fixture. What cannot be tested here is whether a
 * real Obsidian installation opens the URI, and that is reported as
 * NOT MACHINE TESTED rather than assumed.
 *
 * @module @watchskill/dsh-adapters/obsidian
 */
import type { MemoryRecord } from '@watchskill/dsh-memory';
import type { WikiPage, WikiProjection, ValidatedEdit } from '@watchskill/dsh-wiki';
/** One file as it would sit in a vault. */
export interface VaultFile {
    /** Path relative to the vault root. */
    readonly path: string;
    readonly content: string;
    /** Tags in the frontmatter, without the leading hash. */
    readonly tags: readonly string[];
    /** Pages this one links to, by vault path. */
    readonly links: readonly string[];
}
/** A whole exported vault. */
export interface Vault {
    readonly name: string;
    readonly files: readonly VaultFile[];
    /**
     * The note that travels with the export.
     *
     * Present as data rather than as a README somebody might not open: the
     * export writes it into the vault, so a person who arrives at these files
     * from a sync client rather than from Watch still learns what they are.
     */
    readonly readme: string;
}
/** How the export should be shaped. */
export interface VaultOptions {
    readonly name: string;
    /** Prefix inside the vault, so a Watch export can live beside other notes. */
    readonly folder?: string;
    /** Include the log page. Off by default: it is long and rarely read here. */
    readonly includeLog?: boolean;
}
/**
 * Export the wiki as an Obsidian vault.
 *
 * Frontmatter carries tags and the provenance ids, so a person browsing in
 * Obsidian can still see where a statement came from — the graph view is
 * pleasant and it is also a place where provenance is very easy to lose.
 */
export declare function toVault(projection: WikiProjection, options: VaultOptions): Vault;
/**
 * Backlinks, computed from the export rather than read from Obsidian.
 *
 * Computing them here means the export can be checked for a dangling link
 * before anybody opens it, and means the adapter does not need Obsidian to
 * answer a question about its own output.
 */
export declare function backlinks(vault: Vault): ReadonlyMap<string, readonly string[]>;
/** Links that point at a file the export does not contain. */
export declare function danglingLinks(vault: Vault): readonly string[];
/**
 * The URI that opens one page in Obsidian.
 *
 * Constructed, never executed. Handing a URI to the shell is the desktop
 * layer's job and is gated there; an adapter that could launch things would be
 * an adapter that a generated page could aim.
 */
export declare function pageUri(vaultName: string, path: string): string;
/** The URI that opens the vault itself. */
export declare function vaultUri(vaultName: string): string;
/**
 * Strip the frontmatter an export added, so a diff compares like with like.
 *
 * Without this, every imported file would appear to have removed the entire
 * generated page and added an entire new one.
 */
export declare function stripFrontmatter(content: string): string;
/**
 * Import an edited vault file as a proposal.
 *
 * Runs through the wiki's own diff and validation, which is the point: there
 * is one place that decides what an edited file may assert, and an adapter
 * that had its own copy of those rules would be a second place for them to
 * drift.
 */
export declare function importVaultFile(file: {
    readonly path: string;
    readonly content: string;
}, generated: WikiPage): ValidatedEdit;
/**
 * What this adapter can and cannot claim on this machine.
 *
 * Stated as a value so the Settings surface renders the truth rather than a
 * checkmark. Export, backlinks, URI construction and import are all pure and
 * are gated by tests. Whether a real Obsidian installation opens the URI is
 * not something this machine can answer, and it says so.
 */
export interface AdapterAvailability {
    readonly adapterId: string;
    readonly optional: true;
    readonly proven: readonly string[];
    readonly notMachineTested: readonly string[];
}
/** The Obsidian adapter's honest self-description. */
export declare function obsidianAvailability(): AdapterAvailability;
/**
 * Whether a memory record may be written into a shared vault.
 *
 * An export is a copy that leaves the product, and once it is in a synced
 * folder it is wherever that folder goes. Personal taste and anything
 * sensitive stay out by default, and the caller has to say otherwise per
 * export rather than once in a setting.
 */
export declare function mayExport(record: MemoryRecord, options?: {
    readonly includePersonal?: boolean;
}): boolean;
//# sourceMappingURL=obsidian.d.ts.map