/**
 * The Memory workbench.
 *
 * Every card renders every provenance field. That is deliberately more
 * information than a tidy design would show — and it is the right trade,
 * because the failure this surface exists to prevent is a person reading a
 * sentence the system believes about them with no way to tell where it came
 * from, how sure it is, or whether they ever agreed to it.
 *
 * Operations are buttons on the card. A confirm that takes four clicks is a
 * confirm nobody performs, and an uncorrected memory is worse than none.
 *
 * @module @watchskill/dsh-client-memory/components
 */
import type { ReactNode } from 'react';
import type { MemoryEvent } from '@watchskill/dsh-memory';
import { type MemoryCard, type MemoryOperation, type MemoryView } from '../views.js';
/** Props for {@link WhyRememberedChip}. */
export interface WhyRememberedChipProps {
    readonly card: MemoryCard;
}
/**
 * The "Why remembered?" chip.
 *
 * Renders nothing when the memory has never reached a turn. An empty chip that
 * said "no reason recorded" would appear on most cards most of the time, and a
 * signal that is always present is not a signal.
 */
export declare function WhyRememberedChip({ card }: WhyRememberedChipProps): ReactNode;
/** Props for {@link MemoryCardRow}. */
export interface MemoryCardRowProps {
    readonly card: MemoryCard;
    readonly onOperation: (operation: MemoryOperation, memoryId: string) => void;
}
/** One memory, with its provenance and its operations. */
export declare function MemoryCardRow({ card, onOperation }: MemoryCardRowProps): ReactNode;
/** Props for {@link MemoryTimeline}. */
export interface MemoryTimelineProps {
    readonly events: readonly MemoryEvent[];
}
/**
 * The Memory timeline.
 *
 * Events, not records. It is the only surface that shows a memory that no
 * longer exists — as the event that removed it, never as its content — which
 * is what makes "did it actually go?" answerable.
 */
export declare function MemoryTimeline({ events }: MemoryTimelineProps): ReactNode;
/** Props for {@link MemoryWorkbench}. */
export interface MemoryWorkbenchProps {
    readonly view: MemoryView;
    readonly cards: readonly MemoryCard[];
    readonly events: readonly MemoryEvent[];
    /** The durable memory mode this profile is in. */
    readonly mode: 'off' | 'session_only' | 'local_personal' | 'workspace_shared';
    /** The generated wiki, when the wiki view is open. Markdown. */
    readonly wiki?: string;
    readonly onView: (view: MemoryView) => void;
    readonly onOperation: (operation: MemoryOperation, memoryId: string) => void;
}
/**
 * The Memory mode, in the product's own vocabulary.
 *
 * The current mode is stated on every Memory screen rather than hidden in
 * settings, because what a person is looking at means something different in
 * each one: an empty Taste in `off` is correct, and in `local_personal` it is
 * a question.
 */
export declare function MemoryWorkbench(props: MemoryWorkbenchProps): ReactNode;
//# sourceMappingURL=components.d.ts.map