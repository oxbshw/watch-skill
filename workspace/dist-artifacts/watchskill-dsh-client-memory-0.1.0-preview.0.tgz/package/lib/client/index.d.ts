/**
 * The Memory surfaces, registered into DSH's slots.
 *
 * @module @watchskill/dsh-client-memory/client
 */
import type { Context } from '@deepseek-ai/cordis';
export * from './components.js';
export * from '../views.js';
/** Services this half needs before it can register anything. */
export declare const inject: string[];
/**
 * Register the Memory workbench and the conversation chip.
 *
 * The chip goes into the message footer rather than into the Memory surface,
 * because the question it answers — "why does it think that?" — is asked while
 * reading a reply, not while browsing a list.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map